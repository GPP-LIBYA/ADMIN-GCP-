import { Link, useLocation } from 'react-router-dom';
import { 
  LayoutDashboard, 
  Tag, 
  Newspaper, 
  BarChart2, 
  MessageSquare, 
  Eye, 
  Settings as SettingsIcon,
  LogOut,
  Menu,
  X,
  Users,
  History,
  Sun,
  Moon,
  FileText,
  ChevronRight,
  ChevronLeft,
  FileSpreadsheet,
  FileCog,
  Sliders,
  ShieldCheck,
  TrendingUp,
  Inbox,
  Bell,
  ExternalLink
} from 'lucide-react';
import { useAuthStore } from '../store/authStore';
import { useThemeStore } from '../store/themeStore';
import { useState, useEffect, ReactNode } from 'react';
import { cn } from '../lib/utils';
import { supabase } from '../lib/supabase';

interface NavItem {
  name: string;
  href: string;
  icon: any;
  show: boolean;
  badge?: number | null;
}

interface NavGroup {
  id: string;
  label: string;
  items: NavItem[];
}

export default function Layout({ children }: { children: ReactNode }) {
  const { adminUser, signOut } = useAuthStore();
  const { theme, toggleTheme } = useThemeStore();
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isCollapsed, setIsCollapsed] = useState(() => {
    try {
      return localStorage.getItem('gpp_sidebar_collapsed') === 'true';
    } catch {
      return false;
    }
  });
  const [unreadMessages, setUnreadMessages] = useState<number>(0);

  useEffect(() => {
    const fetchUnread = async () => {
      try {
        const { count } = await supabase
          .from('messages')
          .select('*', { count: 'exact', head: true })
          .eq('is_read', false);
        setUnreadMessages(count || 0);
      } catch {
        // Silently ignore
      }
    };
    fetchUnread();
  }, [location.pathname]);

  const toggleCollapse = () => {
    setIsCollapsed(prev => {
      const next = !prev;
      try {
        localStorage.setItem('gpp_sidebar_collapsed', String(next));
      } catch {
        // Ignore
      }
      return next;
    });
  };

  const navGroups: NavGroup[] = [
    {
      id: 'main',
      label: 'الرئيسية',
      items: [
        { 
          name: 'لوحة التحكم', 
          href: '/dashboard', 
          icon: LayoutDashboard, 
          show: true 
        },
      ]
    },
    {
      id: 'prices',
      label: 'إدارة الأسعار',
      items: [
        { 
          name: 'الأسعار الحالية', 
          href: '/prices', 
          icon: Tag, 
          show: Boolean(adminUser?.role === 'super_admin' || adminUser?.can_manage_prices) 
        },
        { 
          name: 'أرشيف الأسعار', 
          href: '/history', 
          icon: History, 
          show: Boolean(adminUser?.role === 'super_admin' || adminUser?.can_manage_prices || adminUser?.can_view_reports) 
        },
      ]
    },
    {
      id: 'reports',
      label: 'التقارير والدراسات',
      items: [
        { 
          name: 'تقارير المنصة', 
          href: '/reports', 
          icon: FileSpreadsheet, 
          show: Boolean(adminUser?.role === 'super_admin') 
        },
        { 
          name: 'التقارير المنشورة', 
          href: '/published-reports', 
          icon: FileText, 
          show: Boolean(adminUser?.role === 'super_admin' || adminUser?.can_manage_analysis) 
        },
        { 
          name: 'إعدادات التقارير', 
          href: '/report-settings', 
          icon: FileCog, 
          show: Boolean(adminUser?.role === 'super_admin' || adminUser?.can_manage_settings) 
        },
      ]
    },
    {
      id: 'content',
      label: 'الأخبار والتحليلات',
      items: [
        { 
          name: 'الأخبار الاقتصادية', 
          href: '/news', 
          icon: Newspaper, 
          show: Boolean(adminUser?.role === 'super_admin' || adminUser?.can_manage_news) 
        },
        { 
          name: 'التحليلات الفنية', 
          href: '/analysis', 
          icon: BarChart2, 
          show: Boolean(adminUser?.role === 'super_admin' || adminUser?.can_manage_analysis) 
        },
      ]
    },
    {
      id: 'communication',
      label: 'الرسائل والزيارات',
      items: [
        { 
          name: 'الرسائل الواردة', 
          href: '/messages', 
          icon: MessageSquare, 
          show: Boolean(adminUser?.role === 'super_admin' || adminUser?.can_manage_messages),
          badge: unreadMessages > 0 ? unreadMessages : null
        },
        { 
          name: 'سجل الزيارات', 
          href: '/visits', 
          icon: Eye, 
          show: Boolean(adminUser?.role === 'super_admin' || adminUser?.can_view_visits) 
        },
      ]
    },
    {
      id: 'system',
      label: 'الإعدادات والمستخدمين',
      items: [
        { 
          name: 'إعدادات المنصة', 
          href: '/settings', 
          icon: SettingsIcon, 
          show: Boolean(adminUser?.role === 'super_admin' || adminUser?.can_manage_settings) 
        },
        { 
          name: 'إدارة المستخدمين', 
          href: '/admins', 
          icon: Users, 
          show: Boolean(adminUser?.role === 'super_admin' || adminUser?.can_manage_admins) 
        },
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-[#0b1120] flex flex-col md:flex-row transition-colors duration-200">
      
      {/* Mobile Header */}
      <header className="md:hidden flex items-center justify-between bg-white dark:bg-[#111c30] border-b border-slate-200 dark:border-slate-800 px-4 py-3 sticky top-0 z-40 shadow-sm">
        <div className="flex items-center gap-3">
          <img 
            src={`${import.meta.env.BASE_URL}logo-ltn.png`} 
            alt="LTN Logo" 
            className="h-9 w-auto"
            onError={(e) => {
              (e.target as HTMLElement).style.display = 'none';
            }}
          />
          <div>
            <div className="text-sm font-black tracking-wide text-[#1e3a8a] dark:text-sky-400">GPP ADMIN</div>
            <div className="text-[10px] text-slate-500 dark:text-slate-400">شبكة ليبيا للتجارة LTN</div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={toggleTheme}
            className="p-2 text-slate-500 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
            aria-label="تبديل الوضع"
          >
            {theme === 'dark' ? <Sun size={20} className="text-amber-400" /> : <Moon size={20} />}
          </button>
          <button 
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="p-2 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg"
            aria-label="القائمة"
          >
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </header>

      {/* Mobile Drawer Overlay */}
      {isMobileMenuOpen && (
        <div 
          className="fixed inset-0 bg-slate-900/60 z-40 md:hidden backdrop-blur-xs transition-opacity"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {/* Sidebar (Desktop Collapsible & Mobile Drawer) */}
      <aside className={cn(
        "bg-white dark:bg-[#111c30] border-l border-slate-200 dark:border-slate-800/80 gpp-sidebar flex flex-col transition-all duration-300 ease-in-out z-50",
        // Desktop sizing
        isCollapsed ? "md:w-20" : "md:w-64",
        // Mobile drawer positioning
        isMobileMenuOpen 
          ? "fixed inset-y-0 right-0 w-80 shadow-2xl flex" 
          : "hidden md:flex sticky top-0 h-screen"
      )}>

        {/* Sidebar Brand Header */}
        <div className="h-[76px] border-b border-slate-200 dark:border-slate-800/80 flex items-center justify-between px-4 relative shrink-0">
          <div className={cn(
            "flex items-center gap-3 transition-opacity duration-200 overflow-hidden",
            isCollapsed && "md:justify-center md:w-full"
          )}>
            <img 
              src={`${import.meta.env.BASE_URL}logo-ltn.png`} 
              alt="LTN Logo" 
              className="h-11 w-auto shrink-0 drop-shadow-xs"
              onError={(e) => {
                (e.target as HTMLElement).style.display = 'none';
              }}
            />
            {(!isCollapsed || isMobileMenuOpen) && (
              <div className="truncate">
                <div className="flex items-center gap-1.5 font-black text-base text-[#1e3a8a] dark:text-sky-400 tracking-tight">
                  <span>GPP ADMIN</span>
                  <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-sm bg-amber-100 text-amber-800 dark:bg-amber-950/70 dark:text-amber-300 border border-amber-300/40">2.0</span>
                </div>
                <div className="text-[11px] text-slate-500 dark:text-slate-400 font-medium truncate">
                  منصة الأسعار العالمية LTN
                </div>
              </div>
            )}
          </div>

          {/* Desktop Collapse Toggle */}
          <button
            onClick={toggleCollapse}
            className="hidden md:flex absolute -left-3 top-1/2 -translate-y-1/2 h-7 w-7 rounded-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-md items-center justify-center text-slate-500 hover:text-[#1e3a8a] dark:hover:text-sky-400 hover:scale-105 transition-all z-10"
            title={isCollapsed ? "توسيع القائمة" : "طي القائمة"}
          >
            {isCollapsed ? <ChevronLeft size={16} /> : <ChevronRight size={16} />}
          </button>
        </div>

        {/* User Status Bar */}
        {(!isCollapsed || isMobileMenuOpen) ? (
          <div className="px-5 py-3.5 border-b border-slate-100 dark:border-slate-800/60 bg-slate-50/70 dark:bg-slate-900/40 flex items-center justify-between shrink-0">
            <div className="flex items-center gap-2.5 truncate">
              <div className="h-8 w-8 rounded-full bg-gradient-to-tr from-[#1e3a8a] to-blue-500 flex items-center justify-center text-white font-black text-xs shrink-0 shadow-xs">
                {(adminUser?.full_name?.[0] || adminUser?.email?.[0] || 'U').toUpperCase()}
              </div>
              <div className="truncate">
                <div className="text-xs font-bold text-slate-800 dark:text-slate-200 truncate">
                  {adminUser?.full_name || adminUser?.email?.split('@')[0]}
                </div>
                <div className="text-[10px] font-semibold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                  <span>{adminUser?.role === 'super_admin' ? 'مدير نظام عام' : (adminUser?.role || 'مسؤول')}</span>
                </div>
              </div>
            </div>

            <button
              onClick={toggleTheme}
              className="p-1.5 text-slate-400 hover:text-slate-700 dark:hover:text-amber-300 rounded-md hover:bg-slate-200/60 dark:hover:bg-slate-800 transition-colors shrink-0"
              title={theme === 'dark' ? "الوضع الفاتح" : "الوضع الداكن"}
            >
              {theme === 'dark' ? <Sun size={17} className="text-amber-400" /> : <Moon size={17} />}
            </button>
          </div>
        ) : (
          <div className="py-3 border-b border-slate-100 dark:border-slate-800/60 flex flex-col items-center gap-2 shrink-0">
            <div 
              className="h-8 w-8 rounded-full bg-gradient-to-tr from-[#1e3a8a] to-blue-500 flex items-center justify-center text-white font-black text-xs shadow-xs"
              title={adminUser?.full_name || adminUser?.email}
            >
              {(adminUser?.full_name?.[0] || 'U').toUpperCase()}
            </div>
            <button
              onClick={toggleTheme}
              className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-amber-300 rounded-md transition-colors"
              title={theme === 'dark' ? "الوضع الفاتح" : "الوضع الداكن"}
            >
              {theme === 'dark' ? <Sun size={16} className="text-amber-400" /> : <Moon size={16} />}
            </button>
          </div>
        )}

        {/* Navigation Groups List */}
        <nav className="flex-1 overflow-y-auto px-3 py-3 space-y-3 scrollbar-thin scrollbar-thumb-slate-200 dark:scrollbar-thumb-slate-800">
          {navGroups.map((group) => {
            const visibleItems = group.items.filter(item => item.show);
            if (visibleItems.length === 0) return null;

            return (
              <div key={group.id} className="space-y-1">
                {/* Group Heading */}
                {(!isCollapsed || isMobileMenuOpen) ? (
                  <div className="px-3 pb-1 text-[11px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-500">
                    {group.label}
                  </div>
                ) : (
                  <div className="my-2 border-t border-slate-100 dark:border-slate-800/60" />
                )}

                {/* Items in group */}
                <div className="space-y-1">
                  {visibleItems.map((item) => {
                    const isActive = location.pathname === item.href || 
                      (item.href !== '/dashboard' && location.pathname.startsWith(item.href));

                    return (
                      <Link
                        key={item.href}
                        to={item.href}
                        onClick={() => setIsMobileMenuOpen(false)}
                        title={isCollapsed && !isMobileMenuOpen ? item.name : undefined}
                        className={cn(
                          "group relative flex items-center gap-3 rounded-lg px-3 py-2.5 text-[13px] font-medium transition-all duration-150",
                          isCollapsed && !isMobileMenuOpen ? "justify-center px-2" : "",
                          isActive
                            ? "bg-blue-50 text-[#173B81] dark:bg-blue-900/35 dark:text-blue-200 font-bold"
                            : "text-slate-600 hover:bg-slate-100/90 dark:text-slate-300 dark:hover:bg-slate-800/60 hover:text-slate-900 dark:hover:text-white"
                        )}
                      >
                        {/* Active line indicator on right in RTL */}
                        {isActive && (
                          <span className="absolute right-0 inset-y-1.5 w-1 rounded-l-full bg-amber-400" />
                        )}

                        <item.icon 
                          size={19} 
                          className={cn(
                            "shrink-0 transition-transform duration-150 group-hover:scale-110",
                            isActive 
                              ? "text-[#1d4ed8] dark:text-blue-300" 
                              : "text-slate-400 group-hover:text-slate-700 dark:text-slate-400 dark:group-hover:text-slate-200"
                          )} 
                        />

                        {(!isCollapsed || isMobileMenuOpen) && (
                          <span className="truncate flex-1">{item.name}</span>
                        )}

                        {/* Badge (e.g. unread messages) */}
                        {item.badge !== undefined && item.badge !== null && (
                          <span className={cn(
                            "inline-flex items-center justify-center text-[11px] font-bold rounded-full px-2 py-0.5 min-w-[20px] transition-transform",
                            isActive 
                              ? "bg-[#173B81] text-white" 
                              : "bg-red-500 text-white shadow-xs"
                          )}>
                            {item.badge}
                          </span>
                        )}
                      </Link>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </nav>

        {/* Sidebar Footer (Sign Out) */}
        <div className="p-3 border-t border-slate-200 dark:border-slate-800/80 shrink-0">
          <button
            onClick={() => signOut()}
            className={cn(
              "flex w-full items-center gap-3 rounded-lg px-3 py-2 text-sm font-bold text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors",
              isCollapsed && !isMobileMenuOpen ? "justify-center px-2" : ""
            )}
            title={isCollapsed && !isMobileMenuOpen ? "تسجيل الخروج" : undefined}
          >
            <LogOut size={18} className="shrink-0" />
            {(!isCollapsed || isMobileMenuOpen) && <span>تسجيل الخروج</span>}
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 min-w-0 overflow-x-hidden bg-[#f6f8fc] dark:bg-[#0b1120]">
        <div className="hidden md:flex h-[76px] items-center justify-between gap-4 border-b border-slate-200/80 dark:border-slate-800 bg-white/90 dark:bg-[#111c30] px-6 lg:px-8">
          <div className="flex items-center gap-3 min-w-0">
            <div className="h-9 w-1 rounded-full bg-[#D4A72C]" />
            <div>
              <div className="text-sm font-bold text-slate-900 dark:text-white">منصة الأسعار العالمية</div>
              <div className="text-[11px] text-slate-500 dark:text-slate-400">نظام الإدارة والتحكم · شبكة ليبيا للتجارة</div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <span className="hidden lg:inline-flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 border border-slate-200 dark:border-slate-700 rounded-full px-3 py-1.5">
              <span className="h-1.5 w-1.5 bg-emerald-500 rounded-full" /> بيئة الإدارة
            </span>
            <button onClick={toggleTheme} title="تبديل المظهر" aria-label="تبديل المظهر" className="p-2 rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800 dark:text-slate-300">{theme === 'dark' ? <Sun size={18}/> : <Moon size={18}/>}</button>
            <span className="h-8 w-8 rounded-full bg-[#173B81] text-white grid place-items-center text-xs font-bold" title={adminUser?.full_name || 'المسؤول'}>{(adminUser?.full_name?.[0] || 'A').toUpperCase()}</span>
          </div>
        </div>
        <div className="gpp-content mx-auto w-full max-w-[1580px] p-4 sm:p-6 lg:px-8 lg:py-7">
          {children}
        </div>
      </main>
    </div>
  );
}
