import { archiveCommodityPrices } from '../utils/historyHelper';
import React, { useState, useEffect, FormEvent, useRef, ChangeEvent } from 'react';
import { supabase } from '../lib/supabase';
import type { Commodity, CommodityCatalog, UnitsCatalog, SectorCatalog } from '../types';
import { useAuthStore } from '../store/authStore';
import { Search, Edit2, Check, X, Filter, Plus, Upload, AlertCircle, FileText, Trash2, Package, CheckSquare, Download, Eye, EyeOff, TrendingUp } from 'lucide-react';
import Papa from 'papaparse';
import * as XLSX from 'xlsx';
import PriceChartModal from '../components/PriceChartModal';
import { formatAdminDateTime, getDayKey } from '../utils/dateUtils';
import { calculateDailyHighLow, getExistingPricesForDay } from '../utils/priceHighLowHelper';

export default function Prices() {
  const { adminUser, session } = useAuthStore();
  const currentAdminId = adminUser?.id || session?.user?.id || null;
  const [commodities, setCommodities] = useState<Commodity[]>([]);
  const [catalogCommodities, setCatalogCommodities] = useState<CommodityCatalog[]>([]);
  const [catalogSectors, setCatalogSectors] = useState<SectorCatalog[]>([]);
  const [catalogUnits, setCatalogUnits] = useState<UnitsCatalog[]>([]);
  const [adminUsersMap, setAdminUsersMap] = useState<Record<string, { full_name?: string; email: string }>>({});
  const [todayPricesMap, setTodayPricesMap] = useState<Map<string, number[]>>(new Map());
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  
  const [isQuickAddCommodityOpen, setIsQuickAddCommodityOpen] = useState(false);
  const [quickCommodityForm, setQuickCommodityForm] = useState({ symbol: '', name_ar: '', name_en: '', sector: '', default_unit: '' });
  
  const [isQuickAddUnitOpen, setIsQuickAddUnitOpen] = useState(false);
  const [quickUnitForm, setQuickUnitForm] = useState({ unit_code: '', unit_ar: '', unit_en: '' });
  
  const [savingQuick, setSavingQuick] = useState(false);
  
  // Tabs
  const [activeTab, setActiveTab] = useState<'list' | 'import'>('list');

  // Search & Filter
  const [search, setSearch] = useState('');
  const [showAuditColumns, setShowAuditColumns] = useState(false);
  const [sectorFilter, setSectorFilter] = useState<string>('all');
  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');
  
  // Bulk Entry State
  const [bulkSector, setBulkSector] = useState('');
  const [bulkItems, setBulkItems] = useState<any[]>([]);
  const [globalSource, setGlobalSource] = useState('Manual Entry');
  const [bulkSaving, setBulkSaving] = useState(false);
  const [bulkResults, setBulkResults] = useState<{ success: number, ignored: number, failed: number, errors: string[] } | null>(null);

  // Pagination
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const ITEMS_PER_PAGE = 50;
  
  // Edit & Add State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isChartModalOpen, setIsChartModalOpen] = useState(false);
  const [chartModalItem, setChartModalItem] = useState<{symbol: string; name_ar: string; name_en: string; sector: string} | null>(null);
  const [editingItem, setEditingItem] = useState<Commodity | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [form, setForm] = useState<Partial<Commodity>>({
    symbol: '', name_ar: '', name_en: '', sector: '', price: 0, unit: '', source: '', status: 'active', is_visible: true
  });
  const [saving, setSaving] = useState(false);
  const [searchCommodity, setSearchCommodity] = useState('');

  // Import State
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [importData, setImportData] = useState<any[]>([]);
  const [importing, setImporting] = useState(false);
  const [importResult, setImportResult] = useState<{added: number, updated: number, failed: number, warnings: string[]} | null>(null);

  // Bulk Actions
  const [selectedSymbols, setSelectedSymbols] = useState<string[]>([]);
  const [bulkActionLoading, setBulkActionLoading] = useState(false);

  useEffect(() => {
    fetchData();
  }, [page, sectorFilter, fromDate, toDate, search]);

  const fetchData = async () => {
    try {
      setLoading(true);
      setError(null);
      
      let query = supabase.from('commodities').select('*', { count: 'exact' });
      
      if (sectorFilter !== 'all') {
        query = query.eq('sector', sectorFilter);
      }
      if (search) {
        query = query.or(`symbol.ilike.%${search}%,name_ar.ilike.%${search}%,name_en.ilike.%${search}%`);
      }
      if (fromDate) {
        query = query.gte('updated_at', new Date(fromDate).toISOString());
      }
      if (toDate) {
        const to = new Date(toDate);
        to.setHours(23, 59, 59, 999);
        query = query.lte('updated_at', to.toISOString());
      }
      
      query = query.order('updated_at', { ascending: false });
      
      const from = (page - 1) * ITEMS_PER_PAGE;
      const to = from + ITEMS_PER_PAGE - 1;
      query = query.range(from, to);

      const [commsRes, catCommsRes, catUnitsRes, catSectorsRes, adminsRes] = await Promise.all([
        query,
        supabase.from('commodity_catalog').select('*').eq('is_active', true),
        supabase.from('units_catalog').select('*').eq('is_active', true),
        supabase.from('sectors_catalog').select('*').eq('is_active', true).order('sort_order', { ascending: true }).order('name_ar', { ascending: true }),
        supabase.from('admin_users').select('id, full_name, email')
      ]);
        
      if (commsRes.error) throw commsRes.error;
      
      setCommodities(commsRes.data || []);
      if (commsRes.count !== null) {
        setTotalPages(Math.ceil(commsRes.count / ITEMS_PER_PAGE));
      }
      setCatalogCommodities(catCommsRes.data || []);
      setCatalogUnits(catUnitsRes.data || []);
      setCatalogSectors(catSectorsRes.data || []);

      if (adminsRes.data) {
        const map: Record<string, { full_name?: string; email: string }> = {};
        adminsRes.data.forEach((u: any) => {
          if (u.id) {
            map[u.id] = { full_name: u.full_name, email: u.email };
          }
          if (u.email) {
            map[u.email] = { full_name: u.full_name, email: u.email };
          }
        });
        setAdminUsersMap(map);
      }

      // Fetch today's prices map to accurately compute and display daily High and Low
      const todayMap = await getExistingPricesForDay(supabase, [], new Date());
      setTodayPricesMap(todayMap);
    } catch (err: any) {
      console.error(err);
      setError('حدث خطأ في جلب بيانات الأسعار');
    } finally {
      setLoading(false);
    }
  };

  const getTodayPriceStats = (item: Commodity) => {
    const sym = (item.symbol || '').trim().toUpperCase();
    const prices = todayPricesMap.get(sym);
    if (prices && prices.length > 0) {
      return {
        high: Math.max(...prices),
        low: Math.min(...prices),
        hasTodayPrice: true
      };
    }
    const isToday = getDayKey(item.updated_at) === getDayKey(new Date());
    if (isToday) {
      const h = typeof item.high === 'number' && !isNaN(item.high) ? item.high : item.price;
      const l = typeof item.low === 'number' && !isNaN(item.low) ? item.low : item.price;
      return {
        high: Math.max(h, item.price),
        low: Math.min(l, item.price),
        hasTodayPrice: true
      };
    }
    return {
      high: null,
      low: null,
      hasTodayPrice: false
    };
  };

  const getAdminDisplayName = (userId?: string | null) => {
    if (!userId) return 'غير معروف';
    const admin = adminUsersMap[userId];
    if (!admin) return 'غير معروف';
    return admin.full_name || admin.email || 'غير معروف';
  };

  const openAddModal = () => {
    setEditingItem(null);
    setSearchCommodity('');
    setForm({
      symbol: '', name_ar: '', name_en: '', sector: '', price: 0, unit: '', source: '', status: 'active', is_visible: true
    });
    setIsModalOpen(true);
  };

  const openEditModal = (item: Commodity) => {
    setEditingItem(item);
    setSearchCommodity('');
    setForm({ ...item });
    setIsModalOpen(true);
  };

  const openChartModal = (item: Commodity) => {
    setChartModalItem({
      symbol: item.symbol,
      name_ar: item.name_ar,
      name_en: item.name_en,
      sector: item.sector
    });
    setIsChartModalOpen(true);
  };

  const deleteCommodity = async (id: string) => {
    if (!adminUser?.can_manage_prices && adminUser?.role !== 'super_admin') {
      alert("ليس لديك صلاحية لحذف الأسعار");
      return;
    }

    if (deletingId !== id) {
      setDeletingId(id);
      return;
    }

    try {
      const { error: err } = await supabase.from('commodities').delete().eq('id', id);
      if (err) throw err;
      setCommodities(prev => prev.filter(c => c.id !== id));
      setSelectedSymbols(prev => {
        const deletedComm = commodities.find(c => c.id === id);
        return deletedComm ? prev.filter(s => s !== deletedComm.symbol) : prev;
      });
    } catch (err) {
      console.error(err);
      alert('حدث خطأ أثناء الحذف');
    } finally {
      setDeletingId(null);
    }
  };

  const handleBulkAction = async (action: 'hide' | 'show' | 'activate' | 'suspend' | 'delete') => {
    if (selectedSymbols.length === 0) return;
    
    const isSuperAdmin = adminUser?.role === 'super_admin';
    const canManagePrices = isSuperAdmin || adminUser?.can_manage_prices;

    if (!canManagePrices) {
      alert("ليس لديك صلاحية لتعديل الأسعار");
      return;
    }

    if (action === 'delete') {
      if (!isSuperAdmin) {
         alert("ليس لديك صلاحية لحذف الأسعار");
         return;
      }
      if (!window.confirm(`هل أنت متأكد من حذف ${selectedSymbols.length} سلعة محددة؟`)) return;
    }

    setBulkActionLoading(true);
    try {
      const now = new Date().toISOString();
      if (action === 'delete') {
         const { error } = await supabase.from('commodities').delete().in('symbol', selectedSymbols);
         if (error) throw error;
         setCommodities(prev => prev.filter(c => !selectedSymbols.includes(c.symbol)));
         setSelectedSymbols([]);
      } else {
         let updateData: any = { updated_at: now };
         if (action === 'hide') updateData.is_visible = false;
         if (action === 'show') updateData.is_visible = true;
         if (action === 'activate') updateData.status = 'active';
         if (action === 'suspend') updateData.status = 'inactive';

         const { error } = await supabase.from('commodities').update(updateData).in('symbol', selectedSymbols);
         if (error) throw error;
         
         setCommodities(prev => prev.map(c => {
           if (selectedSymbols.includes(c.symbol)) {
             return { ...c, ...updateData };
           }
           return c;
         }));
      }
    } catch (err: any) {
      console.error(err);
      alert('حدث خطأ أثناء تنفيذ الإجراء');
    } finally {
      setBulkActionLoading(false);
    }
  };

  const exportSelectedToExcel = async () => {
     if (selectedSymbols.length === 0) return;
     
     setBulkActionLoading(true);
     try {
       const { data, error } = await supabase.from('commodities').select('*').in('symbol', selectedSymbols);
       if (error) throw error;
       
       const exportData = (data || []).map(item => ({
          symbol: item.symbol,
          name_ar: item.name_ar,
          name_en: item.name_en,
          sector: item.sector,
          price: item.price,
          previous_price: item.previous_price,
          change_value: item.change_value,
          change_percent: item.change_percent,
          trend: item.trend,
          unit: item.unit,
          source: item.source,
          status: item.status,
          is_visible: item.is_visible,
          created_by: getAdminDisplayName(item.created_by),
          updated_by: getAdminDisplayName(item.updated_by),
          updated_at: formatAdminDateTime(item.updated_at)
       }));

       const ws = XLSX.utils.json_to_sheet(exportData);
       const wb = XLSX.utils.book_new();
       XLSX.utils.book_append_sheet(wb, ws, "Selected_Prices");
       XLSX.writeFile(wb, `Selected_Prices_${new Date().toISOString().split('T')[0]}.xlsx`);
     } catch (err) {
       console.error(err);
       alert('حدث خطأ أثناء التصدير');
     } finally {
       setBulkActionLoading(false);
     }
  };

  const handleQuickSaveCommodity = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickCommodityForm.symbol || !quickCommodityForm.name_ar || !quickCommodityForm.name_en || !quickCommodityForm.sector) return;
    setSavingQuick(true);
    const sym = quickCommodityForm.symbol.trim().toUpperCase();
    const { data: existing } = await supabase.from('commodity_catalog').select('id').eq('symbol', sym).single();
    if (existing) {
      setSavingQuick(false);
      if (!window.confirm('هذه السلعة موجودة مسبقًا، هل تريد تحديث بياناتها واستخدامها؟')) {
        return;
      }
      setSavingQuick(true);
    }
    const payload = {
      symbol: sym,
      name_ar: quickCommodityForm.name_ar,
      name_en: quickCommodityForm.name_en,
      sector: quickCommodityForm.sector.trim().toLowerCase(),
      default_unit: quickCommodityForm.default_unit,
      is_active: true,
      updated_at: new Date().toISOString()
    };
    const { data, error: err } = await supabase.from('commodity_catalog').upsert(payload, { onConflict: 'symbol' }).select().single();
    if (err) {
      console.error(err);
      if (err.code === '23505') {
        alert('السلعة موجودة مسبقًا، يمكنك تعديلها من القائمة.');
      } else {
        alert('خطأ أثناء الحفظ');
      }
    } else if (data) {
      // update list to include or update
      const existingIdx = catalogCommodities.findIndex(c => c.symbol === sym);
      if (existingIdx !== -1) {
         const newCatalog = [...catalogCommodities];
         newCatalog[existingIdx] = data;
         setCatalogCommodities(newCatalog);
      } else {
         setCatalogCommodities([...catalogCommodities, data]);
      }
      setForm({...form, symbol: sym, name_ar: payload.name_ar, name_en: payload.name_en, sector: payload.sector, unit: payload.default_unit});
      setIsQuickAddCommodityOpen(false);
      setQuickCommodityForm({ symbol: '', name_ar: '', name_en: '', sector: '', default_unit: '' });
      alert('تم حفظ السلعة بنجاح');
    }
    setSavingQuick(false);
  };

  const handleQuickSaveUnit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!quickUnitForm.unit_code) return;
    setSavingQuick(true);
    const { data: existing } = await supabase.from('units_catalog').select('id').eq('unit_code', quickUnitForm.unit_code).single();
    if (existing) {
      alert('هذه الوحدة موجودة مسبقاً');
      setSavingQuick(false);
      return;
    }
    const payload = {
      ...quickUnitForm,
      is_active: true,
      updated_at: new Date().toISOString()
    };
    const { data, error: err } = await supabase.from('units_catalog').insert([{ ...payload, created_at: new Date().toISOString() }]).select().single();
    if (err) {
      console.error(err);
      alert('خطأ أثناء حفظ الوحدة');
    } else if (data) {
      setCatalogUnits([...catalogUnits, data]);
      setForm({...form, unit: payload.unit_code});
      setIsQuickAddUnitOpen(false);
      setQuickUnitForm({ unit_code: '', unit_ar: '', unit_en: '' });
    }
    setSavingQuick(false);
  };

  const fetchBulkItems = async (sector: string) => {
    setBulkSector(sector);
    if (!sector) {
      setBulkItems([]);
      return;
    }
    setLoading(true);
    try {
      const [catalogRes, currentPricesRes] = await Promise.all([
        supabase.from('commodity_catalog').select('*').eq('sector', sector).eq('is_active', true).order('symbol'),
        supabase.from('commodities').select('symbol, price, source, status, is_visible').eq('sector', sector)
      ]);
      
      if (catalogRes.error) throw catalogRes.error;
      
      const currentPricesMap = new Map((currentPricesRes.data || []).map(p => [p.symbol, p]));
      
      const items = (catalogRes.data || []).map(cat => {
        const curr = currentPricesMap.get(cat.symbol);
        return {
          symbol: cat.symbol,
          name_ar: cat.name_ar,
          name_en: cat.name_en,
          unit: cat.default_unit,
          current_price: curr ? curr.price : 0,
          new_price: '',
          source: curr?.source || globalSource,
          status: curr ? curr.status : 'active',
          is_visible: curr ? curr.is_visible : true,
        };
      });
      
      setBulkItems(items);
      setBulkResults(null);
    } catch (err) {
      console.error(err);
      alert('حدث خطأ أثناء جلب البيانات');
    } finally {
      setLoading(false);
    }
  };

  const handleBulkSave = async () => {
    if (!adminUser?.can_manage_prices && adminUser?.role !== 'super_admin') {
      alert("ليس لديك صلاحية لتعديل/إضافة الأسعار");
      return;
    }
    
    const itemsToUpdate = bulkItems.filter(item => item.new_price !== '' && !isNaN(Number(item.new_price)));
    
    if (itemsToUpdate.length === 0) {
      alert('لا توجد أسعار جديدة للحفظ');
      return;
    }
    
    if (!window.confirm(`هل أنت متأكد من حفظ ${itemsToUpdate.length} سعر؟`)) return;

    setBulkSaving(true);
    setBulkResults(null);
    
    let successCount = 0;
    let failedCount = 0;
    const errors: string[] = [];
    const now = new Date().toISOString();
    
    // Fetch today's price history for all items being updated
    const symbolsToUpdate = itemsToUpdate.map(i => i.symbol);
    const dayPricesMap = await getExistingPricesForDay(supabase, symbolsToUpdate, now);

    // We will do it sequentially to track exactly which ones failed without stopping others
    for (const item of itemsToUpdate) {
      try {
        const current_price = Number(item.current_price);
        const new_price = Number(item.new_price);
        const change_value = new_price - current_price;
        const change_percent = current_price !== 0 ? Number(((change_value / current_price) * 100).toFixed(2)) : 0;
        const trend = new_price > current_price ? 'up' : new_price < current_price ? 'down' : 'neutral';

        const sym = String(item.symbol).trim().toUpperCase();
        const existingPrices = dayPricesMap.get(sym) || [];
        const { high, low } = calculateDailyHighLow(existingPrices, new_price);
        existingPrices.push(new_price);
        dayPricesMap.set(sym, existingPrices);

        const payload: any = {
          symbol: item.symbol,
          name_ar: item.name_ar,
          name_en: item.name_en,
          sector: bulkSector,
          price: new_price,
          previous_price: item.current_price > 0 ? item.current_price : new_price,
          change_value: item.current_price > 0 ? change_value : 0,
          change_percent: item.current_price > 0 ? change_percent : 0,
          trend: item.current_price > 0 ? trend : 'neutral',
          high,
          low,
          unit: item.unit || null,
          source: item.source || null,
          status: item.status,
          is_visible: item.is_visible,
          last_update_method: 'manual_bulk',
          updated_at: now
        };
        
        const { data, error } = await supabase.from('commodities').upsert([payload], { onConflict: 'symbol' }).select().single();
        if (!error && data) {
           await archiveCommodityPrices(supabase, [{
             ...data,
             high,
             low,
             created_by: currentAdminId,
             updated_by: currentAdminId,
           }]);
        }
        
        if (error) {
          failedCount++;
          errors.push(`فشل ${item.symbol}: ${error.message}`);
        } else {
          successCount++;
        }
      } catch (err: any) {
        failedCount++;
        errors.push(`فشل ${item.symbol}: ${err.message}`);
      }
    }
    
    setBulkResults({
      success: successCount,
      ignored: bulkItems.length - itemsToUpdate.length,
      failed: failedCount,
      errors
    });
    
    setBulkSaving(false);
    fetchData(); // Refresh list data
  };

  const handleSaveSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!adminUser?.can_manage_prices && adminUser?.role !== 'super_admin') {
      alert("ليس لديك صلاحية لتعديل/إضافة الأسعار");
      return;
    }

    if (!form.price || form.price <= 0) {
       alert("السعر غير صالح");
       return;
    }
    
    try {
      setSaving(true);
        const symbol = form.symbol?.trim().toUpperCase();

        if (editingItem) {
          // Edit mode
          const newPrice = Number(form.price);
          const oldPrice = editingItem.price;
          
          let previous_price = oldPrice;
          let change_value = null;
          let change_percent = null;
          let trend: 'up' | 'down' | 'neutral' = 'neutral';
          
          if (newPrice !== oldPrice) {
            change_value = newPrice - oldPrice;
            change_percent = oldPrice ? (change_value / oldPrice) * 100 : 0;
            trend = newPrice > oldPrice ? 'up' : 'down';
          } else {
            previous_price = editingItem.previous_price || previous_price;
            change_value = editingItem.change_value;
            change_percent = editingItem.change_percent;
            trend = editingItem.trend;
          }
          
          const existingMap = await getExistingPricesForDay(supabase, [editingItem.symbol], new Date());
          const existingPrices = existingMap.get(editingItem.symbol.trim().toUpperCase()) || [];
          const { high, low } = calculateDailyHighLow(existingPrices, newPrice);

          const updateData = {
            name_ar: form.name_ar,
            name_en: form.name_en,
            sector: form.sector,
            price: newPrice,
            unit: form.unit || null,
            source: form.source || null,
            previous_price,
            change_value,
            change_percent,
            trend,
            high,
            low,
            status: form.status,
            is_visible: form.is_visible,
            last_update_method: 'admin',
            updated_at: new Date().toISOString()
          };
          
          const { data: updatedItem, error: err } = await supabase
            .from('commodities')
            .update(updateData)
            .eq('id', editingItem.id).select().single();
            
          if (!err && updatedItem) {
             await archiveCommodityPrices(supabase, [{
               ...updatedItem,
               high,
               low,
               created_by: currentAdminId,
               updated_by: currentAdminId,
             }]);
          }
            
          if (err) throw err;
          
          fetchData();
          alert('تم حفظ السعر بنجاح');
        } else {
          // Add mode
          const { data: existing, error: checkError } = await supabase
            .from('commodities')
            .select('symbol, price')
            .eq('symbol', symbol)
            .maybeSingle();

          if (checkError) {
             console.error('Check Error:', checkError);
             alert(`خطأ في التحقق من السلعة: ${checkError.message}`);
             setSaving(false);
             return;
          }

          if (existing) {
            const oldPrice = Number(existing.price || 0);
            const newPrice = Number(form.price);
            const changeValue = newPrice - oldPrice;
            const changePercent = oldPrice !== 0 ? Number(((changeValue / oldPrice) * 100).toFixed(2)) : 0;
            const trend = newPrice > oldPrice ? 'up' : newPrice < oldPrice ? 'down' : 'neutral';

            const existingMap = await getExistingPricesForDay(supabase, [symbol], new Date());
            const existingPrices = existingMap.get(symbol.trim().toUpperCase()) || [];
            const { high, low } = calculateDailyHighLow(existingPrices, newPrice);

            const { data: updatedItem, error: err } = await supabase
              .from('commodities')
              .update({
                previous_price: oldPrice,
                price: newPrice,
                change_value: changeValue,
                change_percent: changePercent,
                trend,
                high,
                low,
                unit: form.unit || null,
                source: form.source || null,
                status: form.status,
                is_visible: form.is_visible,
                last_update_method: 'admin',
                updated_at: new Date().toISOString()
              })
              .eq('symbol', symbol).select().single();
              
          if (!err && updatedItem) {
             await archiveCommodityPrices(supabase, [{
               ...updatedItem,
               high,
               low,
               created_by: currentAdminId,
               updated_by: currentAdminId,
             }]);
          }
              
            if (err) {
              console.error(err);
              alert(err.message);
              setSaving(false);
              return;
            } else {
              alert('تم حفظ السعر بنجاح');
            }
          } else {
            const newPrice = Number(form.price);
            const existingMap = await getExistingPricesForDay(supabase, [symbol], new Date());
            const existingPrices = existingMap.get(symbol.trim().toUpperCase()) || [];
            const { high, low } = calculateDailyHighLow(existingPrices, newPrice);

            const { data: insertedItem, error: err } = await supabase.from('commodities').insert({
              symbol,
              name_ar: form.name_ar,
              name_en: form.name_en,
              sector: form.sector,
              price: newPrice,
              previous_price: newPrice,
              change_value: 0,
              change_percent: 0,
              trend: 'neutral',
              high,
              low,
              unit: form.unit || null,
              source: form.source || null,
              status: form.status,
              is_visible: form.is_visible,
              last_update_method: 'admin',
              updated_at: new Date().toISOString()
            }).select().single();
          if (!err && insertedItem) {
             await archiveCommodityPrices(supabase, [{
               ...insertedItem,
               high,
               low,
               created_by: currentAdminId,
               updated_by: currentAdminId,
             }]);
          }

            if (err) {
              console.error(err);
              alert(err.message);
              setSaving(false);
              return;
            } else {
              alert('تم حفظ السعر بنجاح');
            }
          }
          
          fetchData();
        }

        setIsModalOpen(false);
      setForm({
        symbol: '', name_ar: '', name_en: '', sector: 'energy', price: 0, unit: '', source: '', status: 'active', is_visible: true
      });

    } catch (err: any) {
      console.error(err);
      alert(err.message || 'حدث خطأ أثناء الحفظ');
    } finally {
      setSaving(false);
    }
  };

  // CSV Import Logic
  const handleFileUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        const data = results.data
          .map((row: any) => {
            const rowData: any = {};
            Object.keys(row).forEach(key => {
               const val = typeof row[key] === 'string' ? row[key].trim() : row[key];
               const cleanKey = key.toLowerCase().trim();
               rowData[cleanKey] = val;
            });
            return rowData;
          })
          .filter((row: any) => {
            if (!row.symbol) return false;
            const p = Number(row.price);
            if (isNaN(p) || row.price === undefined || row.price === null || row.price === '') return false;
            return true;
          })
          .map((row: any) => ({
             symbol: row.symbol.toUpperCase(),
             name_ar: row.name_ar || '',
             name_en: row.name_en || '',
             sector: (row.sector || '').toLowerCase(),
             price: Number(row.price),
             unit: row.unit || '',
             source: row.source || 'Manual CSV'
          }));
          
        const uniqueMap = new Map();
        data.forEach((r: any) => uniqueMap.set(r.symbol, r));
        const finalData = Array.from(uniqueMap.values());

        if (finalData.length === 0) {
           alert("لم يتم العثور على بيانات صالحة. تأكد من وجود الأعمدة المطلوبة بشكل صحيح واستبعاد الحقول الفارغة أو غير الرقمية للسعر.");
        }
        setImportData(finalData);
        setImportResult(null);
      },
      error: (error) => {
        alert("خطأ في قراءة الملف: " + error.message);
      }
    });
    
    if (e.target) {
      e.target.value = '';
    }
  };

  const applyImport = async () => {
    if (!adminUser?.can_import_prices && adminUser?.role !== 'super_admin') {
      alert("ليس لديك صلاحية لاستيراد الأسعار");
      return;
    }

    if (importData.length === 0) return;

    setImporting(true);
    let addedCount = 0;
    let updatedCount = 0;
    const warnings: string[] = [];
    
    const importProcess = async () => {
      const now = new Date().toISOString();

      const { data: existingRecords, error: fetchErr } = await supabase
        .from('commodities')
        .select('*');

      if (fetchErr) throw fetchErr;

      const existingMap = new Map();
      existingRecords?.forEach(r => existingMap.set(r.symbol, r));

      const rowsToUpsert: any[] = [];
      const isSuperAdmin = adminUser?.role === 'super_admin';

      for (const row of importData) {
        const symbol = row.symbol;
        const price = row.price;
        
        let catalogCommodity = catalogCommodities.find(c => c.symbol === symbol);
        
        if (!catalogCommodity) {
          if (isSuperAdmin) {
            // Auto add
            const { data: newCatItem, error: newCatErr } = await supabase.from('commodity_catalog').insert([{
              symbol,
              name_ar: row.name_ar || symbol,
              name_en: row.name_en || symbol,
              sector: (row.sector || 'commodities').toLowerCase(),
              default_unit: row.unit || '',
              is_active: true,
              updated_at: now
            }]).select().single();
            if (newCatErr) {
               console.error("Failed to add to catalog", newCatErr);
            } else {
               catalogCommodity = newCatItem;
            }
          } else {
            warnings.push(`الرمز ${symbol} غير موجود في قائمة السلع. تم تجاهله.`);
            continue; // Skip
          }
        }
        
        let unit = row.unit || (catalogCommodity ? catalogCommodity.default_unit : null);
        
        // Handle Unit Catalog warning
        if (unit) {
           const unitExists = catalogUnits.find(u => u.unit_code === unit || u.unit_ar === unit || u.unit_en === unit);
           if (!unitExists) {
             if (isSuperAdmin) {
               await supabase.from('units_catalog').insert([{
                 unit_code: unit,
                 unit_ar: unit,
                 unit_en: unit,
                 is_active: true,
                 updated_at: now
               }]);
               // don't really need to fetch it back, just proceed
             } else {
               warnings.push(`الوحدة ${unit} غير موجودة في المرجع.`);
             }
           }
        }

        const existing = existingMap.get(symbol);
        
        // Default from catalog
        // Handle Sector validation
        let sectorCode = catalogCommodity?.sector || row.sector || existing?.sector || 'commodities';
        sectorCode = sectorCode.toLowerCase().replace(/\s+/g, '');

        let sectorExists = catalogSectors.find(s => s.sector_code === sectorCode);
        
        if (!sectorExists) {
          if (isSuperAdmin) {
            // Auto add sector
            await supabase.from('sectors_catalog').insert([{
              sector_code: sectorCode,
              name_ar: sectorCode,
              name_en: sectorCode,
              is_active: true,
              sort_order: catalogSectors.length * 10,
              created_at: now,
              updated_at: now
            }]);
            const newSector = { sector_code: sectorCode, name_ar: sectorCode, name_en: sectorCode, is_active: true, sort_order: catalogSectors.length * 10 } as any;
            catalogSectors.push(newSector);
          } else {
            warnings.push(`نوع السلعة غير موجود في قائمة الأنواع (${sectorCode}) للرمز ${symbol}. تم التخطي.`);
            continue; // Skip
          }
        } else if (!sectorExists.is_active) {
          if (!isSuperAdmin) {
            warnings.push(`نوع السلعة (${sectorCode}) غير مفعل للرمز ${symbol}. تم التخطي.`);
            continue;
          }
        }

        const nameAr = catalogCommodity?.name_ar || row.name_ar || existing?.name_ar || symbol;
        const nameEn = catalogCommodity?.name_en || row.name_en || existing?.name_en || symbol;
        const sector = sectorCode;

        if (existing) {
           let previous_price = existing.price;
           let change_value = existing.change_value;
           let change_percent = existing.change_percent;
           let trend = existing.trend;

           if (existing.price !== price) {
             previous_price = existing.price;
             change_value = price - existing.price;
             change_percent = previous_price ? (change_value / previous_price) * 100 : 0;
             trend = price > previous_price ? 'up' : 'down';
           }
           
           const { id, created_at, ...restExisting } = existing;
           
           rowsToUpsert.push({
             ...restExisting,
             name_ar: nameAr,
             name_en: nameEn,
             sector,
             price,
             unit,
             previous_price,
             change_value,
             change_percent,
             trend,
             source: row.source || existing.source || 'Manual CSV',
             last_update_method: 'csv',
             updated_at: now
           });
           updatedCount++;
        } else {
           rowsToUpsert.push({
             symbol,
             name_ar: nameAr,
             name_en: nameEn,
             sector,
             price,
             unit,
             source: row.source || 'Manual CSV',
             previous_price: price,
             change_value: 0,
             change_percent: 0,
             trend: 'neutral',
             status: 'active',
             is_visible: true,
             last_update_method: 'csv',
             updated_at: now
           });
           addedCount++;
        }
      }

      if (rowsToUpsert.length > 0) {
        const symbols = rowsToUpsert.map(r => r.symbol);
        const dayPricesMap = await getExistingPricesForDay(supabase, symbols, now);

        for (const r of rowsToUpsert) {
          const sym = String(r.symbol).trim().toUpperCase();
          const existingPrices = dayPricesMap.get(sym) || [];
          const { high, low } = calculateDailyHighLow(existingPrices, r.price);
          existingPrices.push(r.price);
          dayPricesMap.set(sym, existingPrices);
          r.high = high;
          r.low = low;
        }

        const { data: upsertedRows, error: upsertErr } = await supabase
          .from('commodities')
          .upsert(rowsToUpsert, { onConflict: 'symbol' }).select();
          
        if (!upsertErr && upsertedRows) {
           await archiveCommodityPrices(supabase, upsertedRows.map(r => ({
             ...r,
             created_by: currentAdminId,
             updated_by: currentAdminId,
           })));
        }
          
        if (upsertErr) throw upsertErr;
      }
    };

    try {
      await Promise.race([
        importProcess(),
        new Promise((_, reject) => setTimeout(() => reject(new Error('انتهى وقت الاتصال (Timeout)')), 5000))
      ]);

      setImportResult({ added: addedCount, updated: updatedCount, failed: importData.length - addedCount - updatedCount, warnings });
      setImportData([]);
      fetchData();

    } catch (err: any) {
      console.error("Import error:", err);
      alert(err.message || "خطأ أثناء الاستيراد");
      setImportResult({ added: 0, updated: 0, failed: importData.length, warnings: ["خطأ أثناء الاستيراد"] });
    } finally {
      setImporting(false);
    }
  };

  const exportExcel = async () => {
    if (!adminUser?.can_manage_prices && !adminUser?.can_view_reports && adminUser?.role !== 'super_admin') {
      alert("ليس لديك صلاحية التصدير");
      return;
    }
    
    if (!fromDate && !toDate && sectorFilter === 'all') {
      if (!window.confirm('أنت على وشك تصدير كمية كبيرة من البيانات، هل تريد الاستمرار؟\nيفضل تحديد تاريخ أو قطاع قبل التصدير.')) {
        return;
      }
    }

    try {
      setLoading(true);
      let query = supabase.from('commodities').select('*');
      
      if (sectorFilter !== 'all') query = query.eq('sector', sectorFilter);
      if (fromDate) query = query.gte('updated_at', new Date(fromDate).toISOString());
      if (toDate) {
        const to = new Date(toDate);
        to.setHours(23, 59, 59, 999);
        query = query.lte('updated_at', to.toISOString());
      }
      
      query = query.order('updated_at', { ascending: false });
      
      const { data, error: err } = await query;
      if (err) throw err;
      if (!data || data.length === 0) {
        alert('لا توجد بيانات للتصدير');
        return;
      }
      
      const rows = data.map(r => ({
        symbol: r.symbol,
        name_ar: r.name_ar,
        name_en: r.name_en,
        sector: r.sector,
        price: r.price,
        previous_price: r.previous_price,
        change_value: r.change_value,
        change_percent: r.change_percent,
        trend: r.trend,
        high: r.high || null,
        low: r.low || null,
        unit: r.unit,
        source: r.source,
        status: r.status,
        is_visible: r.is_visible,
        updated_at: formatAdminDateTime(r.updated_at)
      }));
      
      const worksheet = XLSX.utils.json_to_sheet(rows);
      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, 'Prices');
      
      let fileName = 'prices';
      if (sectorFilter !== 'all') fileName += `_${sectorFilter}`;
      else fileName += '_all';
      
      if (fromDate || toDate) {
         fileName += `_${fromDate || 'start'}_to_${toDate || 'now'}`;
      } else {
         const today = new Date().toISOString().split('T')[0];
         fileName += `_${today}`;
      }
      fileName += '.xlsx';
      
      XLSX.writeFile(workbook, fileName);
    } catch (err) {
      console.error(err);
      alert('حدث خطأ أثناء التصدير');
    } finally {
      setLoading(false);
    }
  };

  const canImport = adminUser?.role === 'super_admin' || adminUser?.can_import_prices;

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div className="space-y-1">
          <div className="text-[11px] font-semibold tracking-wide text-[#1d4ed8] dark:text-blue-300">البيانات والأسواق / الأسعار</div>
          <h1 className="text-[26px] leading-tight font-extrabold text-slate-900 dark:text-white">إدارة الأسعار</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400">عرض الأسعار العالمية ومراجعتها وتحديثها من مكان واحد</p>
        </div>
        
        <div className="flex flex-wrap gap-2">
          <button 
            onClick={exportExcel}
            className="flex items-center gap-2 bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition"
          >
            <Download size={18} />
            تحميل Excel
          </button>
          {canImport && (
            <button 
              onClick={() => setActiveTab(activeTab === 'list' ? 'import' : 'list')}
              className="flex items-center gap-2 bg-white dark:bg-dark-card border dark:border-dark-border text-slate-700 dark:text-slate-300 px-4 py-2 rounded-lg hover:bg-slate-50 dark:hover:bg-slate-800/50 dark:bg-dark-bg transition"
            >
              {activeTab === 'list' ? <Upload size={18} /> : <Search size={18} />}
              {activeTab === 'list' ? 'استيراد CSV' : 'عودة'}
            </button>
          )}
          <button 
            onClick={openAddModal}
            className="flex items-center gap-2 bg-primary-600 text-white px-4 py-2 rounded-lg hover:bg-primary-700 transition"
          >
            <Plus size={18} />
            إضافة سعر يدويًا
          </button>
        </div>
      </div>

      {activeTab === 'list' && (
      <>
        <div className="gpp-filter-panel flex flex-wrap gap-4 w-full bg-white dark:bg-dark-card p-4 rounded-xl border dark:border-dark-border">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute right-3 top-2.5 text-slate-400" size={20} />
            <input 
              type="text" 
              placeholder="بحث بالرمز أو الاسم..." 
              value={search}
              onChange={e => { setSearch(e.target.value); setPage(1); }}
              className="w-full pl-3 pr-10 py-2 border dark:border-dark-border rounded-lg focus:ring-2 focus:ring-primary-500 outline-none dark:bg-dark-card dark:text-white"
            />
          </div>
          <div className="relative flex-1 min-w-[150px]">
            <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">القطاع</label>
            <select 
              value={sectorFilter}
              onChange={e => { setSectorFilter(e.target.value); setPage(1); }}
              className="w-full px-3 py-2 border dark:border-dark-border rounded-lg focus:ring-2 focus:ring-primary-500 outline-none dark:bg-dark-card dark:text-white bg-white dark:bg-dark-card text-sm"
            >
              <option value="all">كل القطاعات</option>
              {catalogSectors.map(s => <option key={s.sector_code} value={s.sector_code}>{s.name_ar}</option>)}
            </select>
          </div>
          <div className="flex-1 min-w-[150px]">
            <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">من تاريخ</label>
            <input type="date" value={fromDate} onChange={e => { setFromDate(e.target.value); setPage(1); }} className="w-full border dark:border-dark-border rounded-lg px-3 py-2 outline-none dark:bg-dark-card dark:text-white focus:ring-2 focus:ring-primary-500 text-sm" />
          </div>
          <div className="flex-1 min-w-[150px]">
            <label className="block text-xs font-medium text-slate-500 dark:text-slate-400 mb-1">إلى تاريخ</label>
            <input type="date" value={toDate} onChange={e => { setToDate(e.target.value); setPage(1); }} className="w-full border dark:border-dark-border rounded-lg px-3 py-2 outline-none dark:bg-dark-card dark:text-white focus:ring-2 focus:ring-primary-500 text-sm" />
          </div>
        </div>

        {selectedSymbols.length > 0 && (
          <div className="bg-primary-50 border dark:border-dark-border border-primary-200 rounded-xl p-3 flex flex-wrap gap-3 items-center">
             <div className="text-primary-800 font-bold px-2">
               تم تحديد {selectedSymbols.length}
             </div>
             <div className="h-6 w-px bg-primary-200 hidden md:block"></div>
             
             <button onClick={() => setSelectedSymbols([])} className="text-sm px-3 py-1.5 rounded-lg bg-white dark:bg-dark-card border dark:border-dark-border text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50 dark:bg-dark-bg transition">
               إلغاء تحديد الكل
             </button>

             {(adminUser?.role === 'super_admin' || adminUser?.can_manage_prices) && (
               <>
                 <button onClick={() => handleBulkAction('show')} disabled={bulkActionLoading} className="text-sm px-3 py-1.5 rounded-lg bg-white dark:bg-dark-card border dark:border-dark-border text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/50 dark:bg-dark-bg transition flex items-center gap-1 disabled:opacity-50">
                   <Eye size={16} /> إظهار للزوار
                 </button>
                 <button onClick={() => handleBulkAction('hide')} disabled={bulkActionLoading} className="text-sm px-3 py-1.5 rounded-lg bg-white dark:bg-dark-card border dark:border-dark-border text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800/50 dark:bg-dark-bg transition flex items-center gap-1 disabled:opacity-50">
                   <EyeOff size={16} /> إخفاء عن الزوار
                 </button>
                 
                 <button onClick={() => handleBulkAction('activate')} disabled={bulkActionLoading} className="text-sm px-3 py-1.5 rounded-lg bg-white dark:bg-dark-card border dark:border-dark-border text-green-700 hover:bg-green-50 transition flex items-center gap-1 disabled:opacity-50">
                   <Check size={16} /> تفعيل الحالة
                 </button>
                 <button onClick={() => handleBulkAction('suspend')} disabled={bulkActionLoading} className="text-sm px-3 py-1.5 rounded-lg bg-white dark:bg-dark-card border dark:border-dark-border text-orange-700 hover:bg-orange-50 transition flex items-center gap-1 disabled:opacity-50">
                   <X size={16} /> تعطيل الحالة
                 </button>
               </>
             )}

             <button onClick={exportSelectedToExcel} className="text-sm px-3 py-1.5 rounded-lg bg-white dark:bg-dark-card border dark:border-dark-border text-blue-700 hover:bg-blue-50 transition flex items-center gap-1">
               <Download size={16} /> تصدير Excel
             </button>

             {adminUser?.role === 'super_admin' && (
                <button onClick={() => handleBulkAction('delete')} disabled={bulkActionLoading} className="text-sm px-3 py-1.5 rounded-lg bg-red-100 text-red-700 hover:bg-red-200 transition flex items-center gap-1 mr-auto disabled:opacity-50">
                  <Trash2 size={16} /> حذف المحدد
                </button>
             )}
          </div>
        )}

        {loading ? (
           <div className="p-8 text-center text-slate-500 dark:text-slate-400">جاري التحميل...</div>
        ) : error ? (
           <div className="p-4 bg-red-50 text-red-600 rounded-lg">{error}</div>
        ) : (
          <div className="gpp-data-panel bg-white dark:bg-dark-card rounded-xl shadow-sm border dark:border-dark-border overflow-hidden">
             <div className="flex flex-wrap items-center justify-between gap-3 px-5 py-4 border-b border-slate-100 dark:border-slate-800">
               <div className="space-y-1">
                 <h2 className="font-bold text-slate-900 dark:text-white">قائمة الأسعار</h2>
                 <p className="text-xs text-slate-500 dark:text-slate-400">{commodities.length} سجل في الصفحة الحالية · الصفحة {page} من {Math.max(1, totalPages)}</p>
               </div>
               <button type="button" onClick={() => setShowAuditColumns(v => !v)} aria-pressed={showAuditColumns} className="rounded-lg border border-slate-200 dark:border-slate-700 px-3 py-2 text-xs font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors">
                 {showAuditColumns ? 'إخفاء تفاصيل التدقيق' : 'إظهار تفاصيل التدقيق'}
               </button>
             </div>
             <div className="overflow-x-auto">
              <table className="gpp-price-table w-full text-sm text-right">
                 <thead className="bg-slate-50 dark:bg-dark-bg text-slate-600 dark:text-slate-400 font-medium border-b dark:border-dark-border">
                   <tr>
                     <th className="px-4 py-3 w-10 text-center">
                       <input 
                         type="checkbox" 
                         className="rounded border-slate-300 dark:border-dark-border dark:border-dark-border text-primary-600 focus:ring-primary-500 w-4 h-4 cursor-pointer"
                         checked={commodities.length > 0 && commodities.every(c => selectedSymbols.includes(c.symbol))}
                         onChange={e => {
                           if (e.target.checked) {
                             const newSymbols = [...new Set([...selectedSymbols, ...commodities.map(c => c.symbol)])];
                             setSelectedSymbols(newSymbols);
                           } else {
                             const currentSymbols = commodities.map(c => c.symbol);
                             setSelectedSymbols(prev => prev.filter(s => !currentSymbols.includes(s)));
                           }
                         }}
                       />
                     </th>
                     <th className="px-4 py-3">الرمز</th>
                     <th className="px-4 py-3">الاسم</th>
                     <th className="px-4 py-3">القطاع</th>
                     <th className="px-4 py-3 text-left">السعر الحالي</th>
                     <th className="px-4 py-3 text-left">السعر السابق</th>
                     <th className="px-4 py-3 text-left">أعلى اليوم</th>
                     <th className="px-4 py-3 text-left">أدنى اليوم</th>
                     <th className={showAuditColumns ? 'px-4 py-3' : 'hidden'}>أُضيف بواسطة</th>
                     <th className={showAuditColumns ? 'px-4 py-3' : 'hidden'}>آخر تعديل بواسطة</th>
                     <th className={showAuditColumns ? 'px-4 py-3 text-center' : 'hidden'}>تحديث</th>
                     <th className="px-4 py-3 text-center">الحالة</th>
                     <th className={showAuditColumns ? 'px-4 py-3 text-center' : 'hidden'}>الظهور</th>
                     <th className="px-4 py-3 text-center">إجراءات</th>
                   </tr>
                 </thead>
                 <tbody className="divide-y divide-slate-100 dark:divide-dark-border dark:border-dark-border">
                   {commodities.map(item => (
                       <tr key={item.id} className={`hover:bg-slate-50/50 dark:hover:bg-slate-800/30 ${selectedSymbols.includes(item.symbol) ? 'bg-primary-50/30 dark:bg-primary-900/30' : ''}`}>
                         <td className="px-4 py-3 text-center">
                           <input 
                             type="checkbox" 
                             className="rounded border-slate-300 dark:border-dark-border dark:border-dark-border text-primary-600 focus:ring-primary-500 w-4 h-4 cursor-pointer"
                             checked={selectedSymbols.includes(item.symbol)}
                             onChange={e => {
                               if (e.target.checked) {
                                 setSelectedSymbols(prev => [...prev, item.symbol]);
                               } else {
                                 setSelectedSymbols(prev => prev.filter(s => s !== item.symbol));
                               }
                             }}
                           />
                         </td>
                         <td className="px-4 py-3 font-medium font-mono text-slate-900 dark:text-white" dir="ltr">{item.symbol}</td>
                         <td className="px-4 py-3 text-slate-800 dark:text-slate-200">{item.name_ar}</td>
                         <td className="px-4 py-3">
                           <span className="bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 px-2.5 py-1 rounded-md text-xs">{catalogSectors.find(sector => sector.sector_code === item.sector)?.name_ar || item.sector}</span>
                         </td>
                         {(() => {
                           const stats = getTodayPriceStats(item);
                           return (
                             <>
                               <td className="px-4 py-3 font-mono font-medium text-left" dir="ltr">
                                 <span className={(item.previous_price != null && Number(item.price) > Number(item.previous_price)) ? 'text-emerald-600 dark:text-emerald-400 font-bold' : (item.previous_price != null && Number(item.price) < Number(item.previous_price)) ? 'text-rose-600 dark:text-rose-400 font-bold' : 'text-slate-900 dark:text-white font-bold'}>
                                   {item.price}
                                 </span>
                               </td>
                               <td className="px-4 py-3 font-mono text-slate-500 dark:text-slate-400 text-left text-xs" dir="ltr">
                                 {item.previous_price !== null && item.previous_price !== undefined ? item.previous_price : '—'}
                               </td>
                               <td className="px-4 py-3 font-mono text-emerald-600 dark:text-emerald-400 text-left text-xs font-semibold" dir="ltr">
                                 {stats.high !== null && stats.high !== undefined ? stats.high : '—'}
                               </td>
                               <td className="px-4 py-3 font-mono text-rose-600 dark:text-rose-400 text-left text-xs font-semibold" dir="ltr">
                                 {stats.low !== null && stats.low !== undefined ? stats.low : '—'}
                               </td>
                             </>
                           );
                         })()}
                         <td className={showAuditColumns ? 'px-4 py-3 whitespace-nowrap' : 'hidden'}>
                           <span className={`text-xs px-2 py-0.5 rounded-md ${
                             item.created_by && adminUsersMap[item.created_by] 
                               ? 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-medium' 
                               : 'text-slate-400 dark:text-slate-500'
                           }`}>
                             {getAdminDisplayName(item.created_by)}
                           </span>
                         </td>
                         <td className={showAuditColumns ? 'px-4 py-3 whitespace-nowrap' : 'hidden'}>
                           <span className={`text-xs px-2 py-0.5 rounded-md ${
                             item.updated_by && adminUsersMap[item.updated_by] 
                               ? 'bg-blue-50 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 font-medium' 
                               : 'text-slate-400 dark:text-slate-500'
                           }`}>
                             {getAdminDisplayName(item.updated_by)}
                           </span>
                         </td>
                         <td className={showAuditColumns ? 'px-4 py-3 text-center text-slate-500 dark:text-slate-400 text-xs whitespace-nowrap' : 'hidden'}>
                           {formatAdminDateTime(item.updated_at)}
                         </td>
                         <td className="px-4 py-3 text-center">
                           <span className={`px-2 py-1 rounded-full text-xs ${
                             item.status === 'active' ? 'bg-green-100 text-green-700' : 
                             item.status === 'suspended' ? 'bg-orange-100 text-orange-700' : 
                             'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300'
                           }`}>
                             {item.status === 'active' ? 'نشط' : item.status === 'suspended' ? 'معلق' : 'مغلق'}
                           </span>
                         </td>
                         <td className={showAuditColumns ? 'px-4 py-3 text-center' : 'hidden'}>
                           {item.is_visible ? 
                             <span className="text-green-500 font-bold block text-center">✓</span> : 
                             <span className="text-slate-300 font-bold block text-center">—</span>
                           }
                         </td>
                         <td className="px-4 py-3 text-center">
                           <div className="flex items-center justify-center gap-2 relative">
                             <button onClick={() => openChartModal(item)} className="p-1.5 text-indigo-600 hover:bg-indigo-50 rounded-md" title="عرض الرسم">
                               <TrendingUp size={16} />
                             </button>
                             <button onClick={() => openEditModal(item)} className="p-1.5 text-primary-600 hover:bg-primary-50 rounded-md">
                               <Edit2 size={16} />
                             </button>
                             <div className="flex flex-col gap-1 items-center">
                               <button 
                                 onClick={() => deleteCommodity(item.id)} 
                                 className={`p-1.5 rounded-md transition ${deletingId === item.id ? 'bg-red-600 text-white shadow min-w-[70px] text-xs font-bold' : 'text-red-500 hover:bg-red-50'}`}
                               >
                                 {deletingId === item.id ? 'تأكيد الحذف' : <Trash2 size={16} />}
                               </button>
                               {deletingId === item.id && (
                                 <button onClick={() => setDeletingId(null)} className="text-xs text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:text-slate-300">إلغاء</button>
                               )}
                             </div>
                           </div>
                         </td>
                       </tr>
                     ))}
                 </tbody>
              </table>
              {commodities.length === 0 && (
                 <div className="p-8 text-center text-slate-500 dark:text-slate-400">لا يوجد بيانات مطابقة</div>
              )}
             </div>
             {totalPages > 1 && (
               <div className="p-4 border-t dark:border-dark-border flex justify-center gap-2 bg-slate-50 dark:bg-dark-bg">
                 <button disabled={page === 1} onClick={() => setPage(p => p - 1)} className="px-3 py-1 border dark:border-dark-border rounded bg-white dark:bg-dark-card hover:bg-slate-100 dark:hover:bg-slate-800 dark:bg-slate-800 disabled:opacity-50 text-sm">السابق</button>
                 <span className="px-3 py-1 text-sm text-slate-600 dark:text-slate-400">صفحة {page} من {totalPages}</span>
                 <button disabled={page === totalPages} onClick={() => setPage(p => p + 1)} className="px-3 py-1 border dark:border-dark-border rounded bg-white dark:bg-dark-card hover:bg-slate-100 dark:hover:bg-slate-800 dark:bg-slate-800 disabled:opacity-50 text-sm">التالي</button>
               </div>
             )}
          </div>
        )}
      </>
      )}

      {/* Import CSV Tab */}
      {activeTab === 'import' && canImport && (
        <div className="bg-white dark:bg-dark-card rounded-xl shadow-sm border dark:border-dark-border p-6">
          <div className="mb-6 border-b dark:border-dark-border pb-4">
            <h2 className="text-lg font-bold mb-2">استيراد الأسعار من ملف CSV</h2>
            <p className="text-sm text-slate-600 dark:text-slate-400">
              يجب أن يحتوي الملف على الأعمدة التالية كصف أول (Header):
              <br/>
              <code className="bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded text-primary-700 font-mono text-xs inline-block mt-2" dir="ltr">symbol, name_ar, name_en, sector, price, unit, source</code>
            </p>
          </div>

          <div className="flex flex-col gap-6">
            <div className="flex items-center justify-center w-full">
                <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-slate-300 dark:border-dark-border dark:border-dark-border border-dashed rounded-lg cursor-pointer bg-slate-50 dark:bg-dark-bg hover:bg-slate-100 dark:hover:bg-slate-800 dark:bg-slate-800 transition">
                    <div className="flex flex-col items-center justify-center pt-5 pb-6">
                        <FileText className="w-8 h-8 text-slate-400 mb-2" />
                        <p className="mb-2 text-sm text-slate-500 dark:text-slate-400"><span className="font-semibold">اضغط لاختيار ملف</span></p>
                        <p className="text-xs text-slate-500 dark:text-slate-400">CSV فقط</p>
                    </div>
                    <input 
                      type="file" 
                      accept=".csv" 
                      ref={fileInputRef} 
                      className="hidden" 
                      onChange={handleFileUpload} 
                    />
                </label>
            </div>

            {importData.length > 0 && (
              <div>
                <h3 className="font-semibold mb-3 flex justify-between items-center">
                  <span>تم العثور على {importData.length} صف صالح</span>
                  <button 
                    onClick={applyImport} 
                    disabled={importing}
                    className="bg-primary-600 text-white px-4 py-2 rounded-lg text-sm flex items-center gap-2 hover:bg-primary-700 disabled:opacity-50"
                  >
                    {importing ? 'جاري الاستيراد...' : 'تأكيد الاستيراد'}
                  </button>
                </h3>
                <div className="border dark:border-dark-border rounded-lg max-h-60 overflow-y-auto bg-slate-50 dark:bg-dark-bg p-2">
                   <table className="w-full text-xs text-right">
                     <thead>
                       <tr className="text-slate-500 dark:text-slate-400 border-b dark:border-dark-border">
                         <th className="py-2 px-2">الرمز</th>
                         <th className="py-2 px-2">الاسم</th>
                         <th className="py-2 px-2">القطاع</th>
                         <th className="py-2 px-2">السعر الجديد</th>
                       </tr>
                     </thead>
                     <tbody className="divide-y divide-slate-100 dark:divide-dark-border dark:border-dark-border">
                        {importData.slice(0, 10).map((row, i) => (
                           <tr key={i}>
                             <td className="py-2 px-2 font-mono" dir="ltr">{row.symbol}</td>
                             <td className="py-2 px-2">{row.name_ar}</td>
                             <td className="py-2 px-2">{row.sector}</td>
                             <td className="py-2 px-2 font-mono" dir="ltr">{row.price}</td>
                           </tr>
                        ))}
                     </tbody>
                   </table>
                   {importData.length > 10 && <div className="text-center py-2 text-slate-400">...و {importData.length - 10} حقول أخرى</div>}
                </div>
              </div>
            )}

            {importResult && (
              <div className={`p-4 rounded-lg flex gap-3 ${importResult.failed > 0 || (importResult.warnings && importResult.warnings.length > 0) ? 'bg-orange-50 border dark:border-dark-border border-orange-200 text-orange-800' : 'bg-green-50 border dark:border-dark-border border-green-200 text-green-800'}`}>
                {importResult.failed > 0 ? <AlertCircle className="mt-0.5 shrink-0" /> : <Check className="mt-0.5 shrink-0" />}
                <div>
                  <h4 className="font-bold">اكتمل الاستيراد</h4>
                  <ul className="text-sm mt-1 list-disc list-inside">
                    <li>تم إضافة: {importResult.added}</li>
                    <li>تم تحديث: {importResult.updated}</li>
                    {importResult.failed > 0 && <li>فشل: {importResult.failed}</li>}
                  </ul>
                  {importResult.warnings && importResult.warnings.length > 0 && (
                    <div className="mt-2 text-xs">
                      <p className="font-bold mb-1">ملاحظات التحذير:</p>
                      <ul className="list-disc list-inside">
                        {importResult.warnings.map((w, i) => <li key={i}>{w}</li>)}
                      </ul>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      )}



      {/* Add / Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-slate-900/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-dark-card rounded-xl shadow-lg w-full max-w-3xl max-h-[90vh] flex flex-col">
            <div className="flex items-center justify-between p-4 border-b dark:border-dark-border">
              <h2 className="text-xl font-bold">{editingItem ? 'تعديل السعر' : 'إضافة سعر جديد يدوياً'}</h2>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-600 dark:text-slate-400"><X size={24} /></button>
            </div>
            
            <div className="p-4 overflow-y-auto flex-1">
              {editingItem ? (
                <form id="add-commodity-form" onSubmit={handleSaveSubmit} className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">القطاع *</label>
                      <select disabled value={form.sector} className="w-full border dark:border-dark-border rounded-lg px-3 py-2 bg-slate-50 dark:bg-dark-bg text-slate-500 dark:text-slate-400 outline-none dark:bg-dark-card dark:text-white">
                        <option value={form.sector}>{catalogSectors.find(s => s.sector_code === form.sector)?.name_ar || form.sector}</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">السلعة *</label>
                      <input type="text" readOnly disabled value={form.symbol} className="w-full border dark:border-dark-border rounded-lg px-3 py-2 bg-slate-50 dark:bg-dark-bg text-slate-500 dark:text-slate-400 outline-none dark:bg-dark-card dark:text-white uppercase" />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">الاسم بالعربي *</label>
                      <input type="text" readOnly disabled value={form.name_ar} 
                        className="w-full border dark:border-dark-border rounded-lg px-3 py-2 bg-slate-50 dark:bg-dark-bg text-slate-500 dark:text-slate-400 outline-none dark:bg-dark-card dark:text-white" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">الاسم بالإنجليزي *</label>
                      <input type="text" dir="ltr" readOnly disabled value={form.name_en} 
                        className="w-full border dark:border-dark-border rounded-lg px-3 py-2 bg-slate-50 dark:bg-dark-bg text-slate-500 dark:text-slate-400 outline-none dark:bg-dark-card dark:text-white" />
                    </div>
                  </div>

                  {editingItem && (() => {
                    const stats = getTodayPriceStats(editingItem);
                    return (
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3 bg-slate-50 dark:bg-dark-bg rounded-lg border dark:border-dark-border text-xs">
                        <div>
                          <span className="text-slate-500 dark:text-slate-400 block mb-0.5">السعر المسجل:</span>
                          <span className="font-mono font-bold text-slate-800 dark:text-slate-200" dir="ltr">{editingItem.price}</span>
                        </div>
                        <div>
                          <span className="text-slate-500 dark:text-slate-400 block mb-0.5">السعر السابق:</span>
                          <span className="font-mono font-semibold text-slate-600 dark:text-slate-400" dir="ltr">
                            {editingItem.previous_price !== null && editingItem.previous_price !== undefined ? editingItem.previous_price : '—'}
                          </span>
                        </div>
                        <div>
                          <span className="text-slate-500 dark:text-slate-400 block mb-0.5">أعلى سعر اليوم:</span>
                          <span className="font-mono font-semibold text-emerald-600 dark:text-emerald-400" dir="ltr">
                            {stats.high !== null && stats.high !== undefined ? stats.high : '—'}
                          </span>
                        </div>
                        <div>
                          <span className="text-slate-500 dark:text-slate-400 block mb-0.5">أقل سعر اليوم:</span>
                          <span className="font-mono font-semibold text-rose-600 dark:text-rose-400" dir="ltr">
                            {stats.low !== null && stats.low !== undefined ? stats.low : '—'}
                          </span>
                        </div>
                      </div>
                    );
                  })()}

                  <div className="grid grid-cols-3 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">السعر الحالي *</label>
                      <input type="number" step="0.0001" required value={form.price} onChange={e => setForm({...form, price: Number(e.target.value)})}
                        className="w-full border dark:border-dark-border rounded-lg px-3 py-2 font-mono focus:ring-primary-500 outline-none dark:bg-dark-card dark:text-white" dir="ltr" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">الوحدة (Unit)</label>
                      <select value={form.unit || ''} onChange={e => setForm({...form, unit: e.target.value})}
                        className="w-full border dark:border-dark-border rounded-lg px-3 py-2 focus:ring-primary-500 outline-none dark:bg-dark-card dark:text-white bg-white dark:bg-dark-card">
                        <option value="">-- اختياري --</option>
                        {catalogUnits.map((u: UnitsCatalog) => (
                          <option key={u.id} value={u.unit_code}>{u.unit_ar} ({u.unit_code})</option>
                        ))}
                        {form.unit && !catalogUnits.find((u: UnitsCatalog) => u.unit_code === form.unit) && (
                          <option value={form.unit}>{form.unit}</option>
                        )}
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">المصدر (Source)</label>
                      <input type="text" value={form.source || ''} onChange={e => setForm({...form, source: e.target.value})}
                        className="w-full border dark:border-dark-border rounded-lg px-3 py-2 focus:ring-primary-500 outline-none dark:bg-dark-card dark:text-white" placeholder="Bloomberg, OANDA..." />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 mt-2">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">الحالة</label>
                      <select value={form.status} onChange={e => setForm({...form, status: e.target.value as any})}
                        className="w-full border dark:border-dark-border rounded-lg px-3 py-2 focus:ring-primary-500 outline-none dark:bg-dark-card dark:text-white bg-white dark:bg-dark-card">
                        <option value="active">نشط</option>
                        <option value="suspended">معلق</option>
                        <option value="closed">مغلق</option>
                      </select>
                    </div>
                    <div className="flex items-center gap-2 pt-6">
                      <input type="checkbox" id="add_visible" checked={form.is_visible} onChange={e => setForm({...form, is_visible: e.target.checked})}
                        className="w-4 h-4 rounded border-slate-300 dark:border-dark-border dark:border-dark-border text-primary-600 focus:ring-primary-500" />
                      <label htmlFor="add_visible" className="text-sm font-medium text-slate-700 dark:text-slate-300">تفعيل الظهور للزوار</label>
                    </div>
                  </div>

                  {editingItem && (
                    <div className="mt-4 p-3 bg-slate-50 dark:bg-dark-bg rounded-lg border dark:border-dark-border grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                      <div>
                        <span className="text-slate-500 dark:text-slate-400 block mb-0.5">أُدخل لأول مرة بواسطة:</span>
                        <span className="font-semibold text-slate-800 dark:text-slate-200">
                          {getAdminDisplayName(editingItem.created_by)}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-500 dark:text-slate-400 block mb-0.5">آخر تعديل بواسطة:</span>
                        <span className="font-semibold text-slate-800 dark:text-slate-200">
                          {getAdminDisplayName(editingItem.updated_by)}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-500 dark:text-slate-400 block mb-0.5">تاريخ آخر تعديل:</span>
                        <span className="font-mono text-slate-700 dark:text-slate-300" dir="ltr">
                          {formatAdminDateTime(editingItem.updated_at)}
                        </span>
                      </div>
                    </div>
                  )}
                </form>
              ) : (
                <div className="space-y-6">
                  {bulkResults && (
                    <div className={`p-4 rounded-lg flex gap-3 ${bulkResults.failed > 0 ? 'bg-orange-50 border dark:border-dark-border border-orange-200 text-orange-800' : 'bg-green-50 border dark:border-dark-border border-green-200 text-green-800'}`}>
                      {bulkResults.failed > 0 ? <AlertCircle className="mt-0.5 shrink-0" /> : <Check className="mt-0.5 shrink-0" />}
                      <div>
                        <h4 className="font-bold">نتيجة الحفظ</h4>
                        <ul className="text-sm mt-1 list-disc list-inside">
                          <li>تم تحديث بنجاح: {bulkResults.success} سلعة</li>
                          <li>تم التجاهل (بدون سعر جديد): {bulkResults.ignored} سلعة</li>
                          {bulkResults.failed > 0 && <li>فشل التحديث: {bulkResults.failed} سلعة</li>}
                        </ul>
                        {bulkResults.errors && bulkResults.errors.length > 0 && (
                          <div className="mt-2 text-xs">
                            <p className="font-bold mb-1">تفاصيل الأخطاء:</p>
                            <ul className="list-disc list-inside text-red-600">
                              {bulkResults.errors.map((err, i) => <li key={i}>{err}</li>)}
                            </ul>
                          </div>
                        )}
                      </div>
                    </div>
                  )}

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">اختر القطاع للتحديث *</label>
                      <select 
                        value={bulkSector}
                        onChange={e => fetchBulkItems(e.target.value)}
                        className="w-full px-3 py-2 border dark:border-dark-border rounded-lg focus:ring-2 focus:ring-primary-500 outline-none dark:bg-dark-card dark:text-white bg-white dark:bg-dark-card"
                      >
                        <option value="">-- اختر القطاع --</option>
                        {catalogSectors.map(s => (
                          <option key={s.sector_code} value={s.sector_code}>{s.name_ar} - {s.sector_code}</option>
                        ))}
                      </select>
                    </div>
                    {bulkItems.length > 0 && (
                      <div>
                        <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">المصدر العام (يطبق على الكل)</label>
                        <input 
                          type="text" 
                          value={globalSource}
                          onChange={e => {
                            setGlobalSource(e.target.value);
                            setBulkItems(bulkItems.map(item => ({ ...item, source: e.target.value })));
                          }}
                          className="w-full px-3 py-2 border dark:border-dark-border rounded-lg focus:ring-2 focus:ring-primary-500 outline-none dark:bg-dark-card dark:text-white"
                        />
                      </div>
                    )}
                  </div>

                  {bulkSector && bulkItems.length === 0 && !loading && (
                    <div className="text-center py-8 text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-dark-bg rounded-lg border dark:border-dark-border">
                      لا توجد سلع مسجلة في هذا القطاع.
                    </div>
                  )}

                  {bulkItems.length > 0 && (
                    <div className="space-y-3 border dark:border-dark-border rounded-xl p-3 bg-slate-50 dark:bg-dark-bg">
                      <div className="flex flex-col md:flex-row gap-2 justify-between items-start md:items-center">
                        <div className="relative w-full md:w-1/2">
                          <Search className="absolute right-3 top-2.5 text-slate-400" size={18} />
                          <input 
                            type="text"
                            placeholder="ابحث داخل القطاع بالرمز أو الاسم..."
                            value={searchCommodity}
                            onChange={e => setSearchCommodity(e.target.value)}
                            className="w-full pl-3 pr-10 py-2 text-sm border dark:border-dark-border rounded-lg outline-none dark:bg-dark-card dark:text-white focus:ring-2 focus:ring-primary-500"
                          />
                        </div>
                        <div className="flex gap-2">
                          <button 
                            onClick={() => setBulkItems(bulkItems.map(item => ({...item, new_price: ''})))}
                            className="px-3 py-1.5 text-xs font-medium border dark:border-dark-border bg-white dark:bg-dark-card text-slate-600 dark:text-slate-400 rounded hover:bg-slate-50 dark:hover:bg-slate-800/50 dark:bg-dark-bg transition"
                          >
                            مسح الأسعار
                          </button>
                          <button 
                            onClick={() => setBulkItems(bulkItems.map(item => ({...item, new_price: item.current_price > 0 ? item.current_price.toString() : ''})))}
                            className="px-3 py-1.5 text-xs font-medium border dark:border-dark-border bg-white dark:bg-dark-card text-slate-600 dark:text-slate-400 rounded hover:bg-slate-50 dark:hover:bg-slate-800/50 dark:bg-dark-bg transition"
                          >
                            نسخ السعر الحالي
                          </button>
                        </div>
                      </div>

                      <div className="border dark:border-dark-border bg-white dark:bg-dark-card rounded-lg overflow-x-auto max-h-[45vh]">
                        <table className="w-full text-sm text-right">
                          <thead className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 sticky top-0 border-b dark:border-dark-border z-10">
                            <tr>
                              <th className="px-3 py-2 font-medium">الرمز</th>
                              <th className="px-3 py-2 font-medium">الاسم</th>
                              <th className="px-3 py-2 font-medium">الوحدة</th>
                              <th className="px-3 py-2 font-medium text-center">السعر الحالي</th>
                              <th className="px-3 py-2 font-medium min-w-[120px]">السعر الجديد</th>
                              <th className="px-3 py-2 font-medium min-w-[100px]">المصدر</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100 dark:divide-dark-border dark:border-dark-border">
                            {bulkItems.filter(item => {
                               if (!searchCommodity) return true;
                               const searchLower = searchCommodity.toLowerCase();
                               return item.symbol.toLowerCase().includes(searchLower) || 
                                      item.name_ar.includes(searchCommodity) || 
                                      (item.name_en && item.name_en.toLowerCase().includes(searchLower));
                            }).map((item) => {
                               const originalIndex = bulkItems.findIndex(b => b.symbol === item.symbol);
                               return (
                                <tr key={item.symbol} className={`${item.new_price !== '' ? 'bg-primary-50/30 dark:bg-primary-900/30' : 'hover:bg-slate-50 dark:hover:bg-slate-800/50'}`}>
                                  <td className="px-3 py-2 font-mono font-medium text-xs" dir="ltr">{item.symbol}</td>
                                  <td className="px-3 py-2 font-medium text-xs truncate max-w-[150px]" title={item.name_ar}>{item.name_ar}</td>
                                  <td className="px-3 py-2 text-slate-500 dark:text-slate-400 text-xs">{item.unit || '-'}</td>
                                  <td className="px-3 py-2 text-center font-mono text-slate-500 dark:text-slate-400 text-xs" dir="ltr">
                                    {item.current_price > 0 ? item.current_price : '-'}
                                  </td>
                                  <td className="px-3 py-2">
                                    <input 
                                      type="number" 
                                      step="any"
                                      placeholder="سعر جديد..."
                                      value={item.new_price}
                                      onChange={(e) => {
                                        const newItems = [...bulkItems];
                                        newItems[originalIndex].new_price = e.target.value;
                                        setBulkItems(newItems);
                                      }}
                                      className={`w-full px-2 py-1.5 text-xs border dark:border-dark-border rounded outline-none dark:bg-dark-card dark:text-white font-mono focus:ring-2 focus:ring-primary-500 ${item.new_price !== '' ? 'bg-white dark:bg-dark-card border-primary-300' : 'bg-slate-50 dark:bg-dark-bg'}`}
                                      dir="ltr"
                                    />
                                  </td>
                                  <td className="px-3 py-2">
                                    <input 
                                      type="text" 
                                      value={item.source || ''}
                                      onChange={(e) => {
                                        const newItems = [...bulkItems];
                                        newItems[originalIndex].source = e.target.value;
                                        setBulkItems(newItems);
                                      }}
                                      className="w-full px-2 py-1.5 text-xs border dark:border-dark-border rounded outline-none dark:bg-dark-card dark:text-white focus:ring-1 focus:ring-primary-500"
                                      placeholder="المصدر"
                                    />
                                  </td>
                                </tr>
                              )
                            })}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
            
            <div className="p-4 border-t dark:border-dark-border flex justify-end gap-3 bg-slate-50 dark:bg-dark-bg rounded-b-xl">
              <button 
                type="button" 
                onClick={() => setIsModalOpen(false)} 
                className="px-4 py-2 border dark:border-dark-border rounded-lg text-sm bg-white dark:bg-dark-card hover:bg-slate-50 dark:hover:bg-slate-800/50 dark:bg-dark-bg transition"
              >
                إلغاء
              </button>
              {editingItem ? (
                <button 
                  type="submit" 
                  form="add-commodity-form" 
                  disabled={saving || !form.symbol} 
                  className="px-4 py-2 bg-primary-600 text-white rounded-lg text-sm font-medium flex items-center gap-2 hover:bg-primary-700 disabled:opacity-50"
                >
                  {saving ? 'جاري الحفظ...' : 'تحديث السعر'}
                </button>
              ) : (
                <button 
                  type="button"
                  onClick={handleBulkSave}
                  disabled={bulkSaving || bulkItems.filter(i => i.new_price !== '').length === 0}
                  className="px-6 py-2 bg-primary-600 text-white rounded-lg text-sm font-bold hover:bg-primary-700 disabled:opacity-50 transition"
                >
                  {bulkSaving ? 'جاري الحفظ...' : 'حفظ جميع الأسعار'}
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {isQuickAddCommodityOpen && (
        <div className="fixed inset-0 bg-slate-900/60 flex items-center justify-center z-[60] p-4">
          <div className="bg-white dark:bg-dark-card rounded-xl shadow-lg w-full max-w-md overflow-hidden flex flex-col">
            <div className="px-6 py-4 border-b dark:border-dark-border flex justify-between items-center bg-slate-50 dark:bg-dark-bg">
              <h3 className="font-bold text-lg text-slate-800 dark:text-slate-200">إضافة سلعة كمرجع سريع</h3>
              <button disabled={savingQuick} onClick={() => setIsQuickAddCommodityOpen(false)} className="text-slate-400 hover:text-slate-600 dark:text-slate-400">
                <X size={20} />
              </button>
            </div>
            <div className="p-6">
              <form onSubmit={handleQuickSaveCommodity} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">الرمز *</label>
                    <input required type="text" value={quickCommodityForm.symbol} onChange={e => setQuickCommodityForm({...quickCommodityForm, symbol: e.target.value.toUpperCase()})} className="w-full border dark:border-dark-border rounded-lg px-3 py-2 uppercase" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">الوحدة *</label>
                    <input required type="text" value={quickCommodityForm.default_unit} onChange={e => setQuickCommodityForm({...quickCommodityForm, default_unit: e.target.value})} className="w-full border dark:border-dark-border rounded-lg px-3 py-2" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">الاسم بالعربية *</label>
                    <input required type="text" value={quickCommodityForm.name_ar} onChange={e => setQuickCommodityForm({...quickCommodityForm, name_ar: e.target.value})} className="w-full border dark:border-dark-border rounded-lg px-3 py-2" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">الاسم بالإنجليزية *</label>
                    <input required type="text" value={quickCommodityForm.name_en} onChange={e => setQuickCommodityForm({...quickCommodityForm, name_en: e.target.value})} className="w-full border dark:border-dark-border rounded-lg px-3 py-2" />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">القطاع *</label>
                  <select required value={quickCommodityForm.sector} onChange={e => setQuickCommodityForm({...quickCommodityForm, sector: e.target.value})} className="w-full border dark:border-dark-border rounded-lg px-3 py-2 bg-white dark:bg-dark-card">
                    <option value="">-- اختر القطاع --</option>
                    {catalogSectors.map(sec => <option key={sec.sector_code} value={sec.sector_code}>{sec.name_ar} - {sec.sector_code}</option>)}
                  </select>
                </div>
                <div className="pt-4 flex justify-end gap-3">
                  <button type="button" onClick={() => setIsQuickAddCommodityOpen(false)} className="px-4 py-2 border dark:border-dark-border rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50 dark:bg-dark-bg">إلغاء</button>
                  <button type="submit" disabled={savingQuick} className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 disabled:opacity-50">
                    {savingQuick ? 'جاري الحفظ...' : 'إضافة واستخدام'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {isQuickAddUnitOpen && (
        <div className="fixed inset-0 bg-slate-900/60 flex items-center justify-center z-[60] p-4">
          <div className="bg-white dark:bg-dark-card rounded-xl shadow-lg w-full max-w-sm overflow-hidden flex flex-col">
            <div className="px-6 py-4 border-b dark:border-dark-border flex justify-between items-center bg-slate-50 dark:bg-dark-bg">
              <h3 className="font-bold text-lg text-slate-800 dark:text-slate-200">إضافة وحدة سريعة</h3>
              <button disabled={savingQuick} onClick={() => setIsQuickAddUnitOpen(false)} className="text-slate-400 hover:text-slate-600 dark:text-slate-400">
                <X size={20} />
              </button>
            </div>
            <div className="p-6">
              <form onSubmit={handleQuickSaveUnit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">الكود (مثال: barrel) *</label>
                  <input required type="text" value={quickUnitForm.unit_code} onChange={e => setQuickUnitForm({...quickUnitForm, unit_code: e.target.value})} className="w-full border dark:border-dark-border rounded-lg px-3 py-2" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">الاسم بالعربية *</label>
                  <input required type="text" value={quickUnitForm.unit_ar} onChange={e => setQuickUnitForm({...quickUnitForm, unit_ar: e.target.value})} className="w-full border dark:border-dark-border rounded-lg px-3 py-2" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-700 dark:text-slate-300 mb-1">الاسم بالإنجليزية *</label>
                  <input required type="text" value={quickUnitForm.unit_en} onChange={e => setQuickUnitForm({...quickUnitForm, unit_en: e.target.value})} className="w-full border dark:border-dark-border rounded-lg px-3 py-2" />
                </div>
                <div className="pt-4 flex justify-end gap-3">
                  <button type="button" onClick={() => setIsQuickAddUnitOpen(false)} className="px-4 py-2 border dark:border-dark-border rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800/50 dark:bg-dark-bg">إلغاء</button>
                  <button type="submit" disabled={savingQuick} className="px-4 py-2 bg-primary-600 text-white rounded-lg hover:bg-primary-700 disabled:opacity-50">
                    {savingQuick ? 'جاري الحفظ...' : 'إضافة واستخدام'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      <PriceChartModal 
        isOpen={isChartModalOpen}
        onClose={() => setIsChartModalOpen(false)}
        commodity={chartModalItem}
      />

    </div>
  );
}
