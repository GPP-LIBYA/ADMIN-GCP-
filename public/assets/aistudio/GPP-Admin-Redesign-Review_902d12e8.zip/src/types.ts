export type AdminRole = 'super_admin' | 'Admin' | 'Editor' | 'Viewer' | string;

export interface AdminUser {
  id: number | string; // Primary key bigint
  auth_user_id?: string; // Linked to auth.users.id UUID
  email: string;
  full_name?: string;
  role: AdminRole;
  is_active: boolean;
  can_manage_admins: boolean;
  can_manage_prices: boolean;
  can_view_reports?: boolean;
  can_import_prices: boolean;
  can_manage_news: boolean;
  can_manage_analysis: boolean;
  can_manage_messages: boolean;
  can_view_visits: boolean;
  can_manage_settings: boolean;
  created_at: string;
  updated_at: string;
}

export interface Commodity {
  id: string;
  symbol: string;
  name_ar: string;
  name_en: string;
  sector: string;
  price: number;
  previous_price: number | null;
  change_value: number | null;
  change_percent: number | null;
  trend: 'up' | 'down' | 'neutral';
  high?: number | null;
  low?: number | null;
  status: 'active' | 'suspended' | 'closed';
  is_visible: boolean;
  unit: string | null;
  source: string | null;
  last_update_method?: string | null;
  created_by?: string | null;
  updated_by?: string | null;
  created_at?: string;
  updated_at: string;
}

export interface NewsArticle {
  id: string;
  title_ar: string;
  title_en: string;
  content_ar: string;
  content_en: string;
  summary_ar: string | null;
  summary_en: string | null;
  source: string | null;
  image_url: string | null;
  is_published: boolean;
  published_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface Report {
  id: string;
  title_ar: string;
  title_en: string;
  description_ar?: string | null;
  description_en?: string | null;
  sector?: string | null;
  keywords?: string[];
  report_date: string;
  status: 'draft' | 'published' | 'archived';
  is_published: boolean;
  cover_image_url?: string | null;
  pdf_url: string;
  file_size?: number | null;
  pages_count?: number | null;
  page_count?: number | null;
  created_by?: string | null;
  views_count?: number;
  downloads_count?: number;
  created_at: string;
  updated_at: string;
}

export interface Analysis {
  id: string | number;
  // Old Analysis fields
  title?: string;
  content?: string;
  asset_symbol?: string | null;
  author?: string | null;
  is_published?: boolean;

  // Report fields
  title_ar?: string;
  title_en?: string;
  description_ar?: string | null;
  description_en?: string | null;
  sector?: string | null;
  tags?: string[];
  report_date?: string;
  status?: 'draft' | 'published' | 'archived';
  cover_image_url?: string | null;
  pdf_url?: string;
  file_size?: number | null;
  page_count?: number | null;
  uploaded_by?: string | null;
  views_count?: number;
  downloads_count?: number;

  created_at: string;
  updated_at: string;
}

export interface Message {
  id: string;
  sender_name: string;
  sender_email: string;
  subject: string;
  body: string;
  is_read: boolean;
  created_at: string;
}

export interface SiteVisit {
  id: string;
  created_at: string;
  visitor_ip: string | null;
  device_type: string | null;
  browser_name: string | null;
  operating_system: string | null;
  screen_width: number | null;
  screen_height: number | null;
  language: string | null;
  page_path: string;
  referrer: string | null;
  session_id: string | null;
  user_agent: string | null;
}

export interface PlatformLogoSettings {
  header_logo_enabled: boolean;
  header_logo_path: string;
  header_logo_height: number;
  header_logo_alignment: 'right' | 'center' | 'left';
  header_logo_order: 'before_text' | 'after_text';
  header_logo_gap: number;

  hero_logo_enabled: boolean;
  hero_logo_path: string;
  hero_logo_size: number;
  hero_logo_alignment: 'right' | 'center' | 'left';
  hero_logo_vertical_position: 'top' | 'center' | 'bottom';
  hero_logo_offset_y: number;
}

export interface PlatformSettings {
  id: string; // single row usually
  site_name: string;
  logo_url: string | null;
  favicon_url: string | null;
  announcement: string | null;
  contact_email: string | null;
  contact_phone: string | null;
  maintenance_mode: boolean;
  report_logo_left?: string | null;
  report_logo_middle?: string | null;
  report_logo_right?: string | null;
  updated_at: string;
}

export interface FooterLogo {
  id: string | number;
  name: string;
  storage_path: string;
  link_url?: string | null;
  display_order: number;
  logo_height: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface SectorCatalog {
  id: string;
  sector_code: string;
  name_ar: string;
  name_en: string;
  description?: string;
  is_active: boolean;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

export interface CommodityCatalog {
  id: string;
  symbol: string;
  name_ar: string;
  name_en: string;
  sector: string;
  default_unit: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface UnitsCatalog {
  id: string;
  unit_code: string;
  unit_ar: string;
  unit_en: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export interface CommodityPriceHistory {
  id: string;
  symbol: string;
  name_ar?: string;
  name_en?: string;
  sector?: string;
  price: number;
  previous_price?: number | null;
  change_value?: number | null;
  change_percent?: number | null;
  trend?: 'up' | 'down' | 'neutral';
  high?: number | null;
  low?: number | null;
  unit?: string | null;
  source?: string | null;
  recorded_at: string;
  update_method?: string | null;
  admin_email?: string | null;
  created_by?: string | null;
  updated_by?: string | null;
  created_at?: string;
  updated_at?: string;
}

