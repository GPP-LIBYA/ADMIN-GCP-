import { useEffect, useState, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import type { Commodity, CommodityPriceHistory, Report, NewsArticle, Message } from '../types';
import { 
  Tag, 
  Eye, 
  Clock, 
  MessageSquare, 
  RefreshCw, 
  TrendingUp, 
  TrendingDown, 
  Minus, 
  Search, 
  ArrowUpRight, 
  BarChart3, 
  FileText, 
  Newspaper, 
  CheckCircle2, 
  AlertCircle,
  Activity,
  Layers,
  Calendar,
  DollarSign,
  ExternalLink
} from 'lucide-react';
import { formatAdminDateTime, formatAdminDate } from '../utils/dateUtils';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid
} from 'recharts';

interface KPIStats {
  activeCommoditiesCount: number;
  todayVisitsCount: number;
  lastPriceUpdate: string | null;
  unreadMessagesCount: number;
}

interface ActivityItem {
  id: string;
  type: 'price' | 'report' | 'news' | 'message';
  title: string;
  subtitle?: string;
  timestamp: string;
  badge?: string;
  badgeColor?: string;
  link?: string;
}

export default function Dashboard() {
  const [stats, setStats] = useState<KPIStats>({
    activeCommoditiesCount: 0,
    todayVisitsCount: 0,
    lastPriceUpdate: null,
    unreadMessagesCount: 0
  });

  const [commodities, setCommodities] = useState<Commodity[]>([]);
  const [priceHistory, setPriceHistory] = useState<CommodityPriceHistory[]>([]);
  const [recentActivities, setRecentActivities] = useState<ActivityItem[]>([]);
  const [selectedSymbol, setSelectedSymbol] = useState<string>('');
  const [tableSearch, setTableSearch] = useState<string>('');
  
  const [loading, setLoading] = useState<boolean>(true);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [refreshSuccess, setRefreshSuccess] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [lastRefreshedTime, setLastRefreshedTime] = useState<string>('');

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async (manualRefresh = false) => {
    try {
      if (manualRefresh) {
        setIsRefreshing(true);
      } else {
        setLoading(true);
      }
      setError(null);

      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const todayISO = today.toISOString();

      // Parallel data fetching across Supabase tables
      const [
        activeCommoditiesRes,
        todayVisitsRes,
        lastPriceRes,
        unreadMessagesRes,
        allCommoditiesRes,
        historyRes,
        reportsRes,
        newsRes
      ] = await Promise.all([
        // 1. Active Commodities Count
        supabase.from('commodities').select('*', { count: 'exact', head: true }).eq('status', 'active'),
        
        // 2. Today's Visits Count (check created_at)
        supabase.from('site_visits').select('*', { count: 'exact', head: true }).gte('created_at', todayISO),
        
        // 3. Last Price Update Record
        supabase.from('commodities').select('updated_at').order('updated_at', { ascending: false }).limit(1).maybeSingle(),
        
        // 4. Unread Messages Count
        supabase.from('messages').select('*', { count: 'exact', head: true }).eq('is_read', false),
        
        // 5. Active Commodities List for Table & Selector
        supabase.from('commodities').select('*').eq('status', 'active').order('updated_at', { ascending: false }),
        
        // 6. Price History for Chart
        supabase.from('commodity_price_history').select('*').order('recorded_at', { ascending: true }).limit(300),
        
        // 7. Recent Reports for Activity
        supabase.from('reports').select('*').order('created_at', { ascending: false }).limit(3),
        
        // 8. Recent News for Activity
        supabase.from('news').select('*').order('created_at', { ascending: false }).limit(3)
      ]);

      const activeComms: Commodity[] = allCommoditiesRes.data || [];
      const historyData: CommodityPriceHistory[] = historyRes.data || [];
      const reportsData: Report[] = reportsRes.data || [];
      const newsData: NewsArticle[] = newsRes.data || [];

      // Update KPI Stats
      setStats({
        activeCommoditiesCount: activeCommoditiesRes.count || activeComms.length || 0,
        todayVisitsCount: todayVisitsRes.count || 0,
        lastPriceUpdate: lastPriceRes.data?.updated_at || (activeComms[0]?.updated_at ?? null),
        unreadMessagesCount: unreadMessagesRes.count || 0
      });

      setCommodities(activeComms);
      setPriceHistory(historyData);

      // Default selected symbol to first commodity if not selected yet
      if (activeComms.length > 0 && !selectedSymbol) {
        setSelectedSymbol(activeComms[0].symbol);
      }

      // Build Chronological Activity Feed
      const activities: ActivityItem[] = [];

      // Recent commodity price updates
      activeComms.slice(0, 3).forEach(c => {
        activities.push({
          id: `comm-${c.id}`,
          type: 'price',
          title: `تحديث سعر ${c.name_ar}`,
          subtitle: `${c.price} ${c.unit || ''} (${c.change_percent ? (c.change_percent > 0 ? `+${c.change_percent}%` : `${c.change_percent}%`) : '0%'})`,
          timestamp: c.updated_at || c.created_at || new Date().toISOString(),
          badge: c.sector,
          badgeColor: 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 border-blue-200 dark:border-blue-800/40',
          link: '/prices'
        });
      });

      // Recent published reports
      reportsData.slice(0, 2).forEach(r => {
        activities.push({
          id: `rep-${r.id}`,
          type: 'report',
          title: `نشر تقرير: ${r.title_ar}`,
          subtitle: r.sector || 'تقرير عام',
          timestamp: r.created_at || new Date().toISOString(),
          badge: 'تقرير PDF',
          badgeColor: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800/40',
          link: '/published-reports'
        });
      });

      // Recent news articles
      newsData.slice(0, 2).forEach(n => {
        activities.push({
          id: `news-${n.id}`,
          type: 'news',
          title: `خبر: ${n.title_ar}`,
          subtitle: n.source || 'أخبار السوق',
          timestamp: n.created_at || new Date().toISOString(),
          badge: 'أخبار',
          badgeColor: 'bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-300 border-amber-200 dark:border-amber-800/40',
          link: '/news'
        });
      });

      // Sort activities newest first
      activities.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
      setRecentActivities(activities.slice(0, 6));

      const nowTime = new Date().toLocaleTimeString('ar-LY', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      setLastRefreshedTime(nowTime);

      if (manualRefresh) {
        setRefreshSuccess(true);
        setTimeout(() => setRefreshSuccess(false), 2500);
      }

    } catch (err: any) {
      console.error('Error fetching dashboard data:', err);
      setError('حدث خطأ أثناء تحميل بيانات لوحة التحكم');
    } finally {
      setLoading(false);
      setIsRefreshing(false);
    }
  };

  // Selected Commodity Object
  const currentCommodity = useMemo(() => {
    return commodities.find(c => c.symbol === selectedSymbol) || commodities[0] || null;
  }, [commodities, selectedSymbol]);

  // Filter Price History for selected commodity
  const chartData = useMemo(() => {
    if (!selectedSymbol) return [];
    
    const symbolMatches = priceHistory.filter(h => 
      h.symbol?.trim().toUpperCase() === selectedSymbol.trim().toUpperCase()
    );

    if (symbolMatches.length === 0) return [];

    return symbolMatches.map(item => ({
      rawDate: item.recorded_at || item.created_at || '',
      date: formatAdminDate(item.recorded_at || item.created_at),
      fullDate: formatAdminDateTime(item.recorded_at || item.created_at),
      price: Number(item.price),
      change: item.change_percent || 0
    }));
  }, [priceHistory, selectedSymbol]);

  // Filtered commodities for the quick table
  const filteredCommodities = useMemo(() => {
    if (!tableSearch.trim()) return commodities.slice(0, 6);
    const q = tableSearch.toLowerCase();
    return commodities.filter(c => 
      c.symbol.toLowerCase().includes(q) ||
      c.name_ar.includes(q) ||
      c.name_en.toLowerCase().includes(q) ||
      c.sector?.includes(q)
    );
  }, [commodities, tableSearch]);

  const formatRelativeTime = (dateString: string | null | undefined): string => {
    if (!dateString) return 'لا يوجد تحديث';
    const now = new Date();
    const date = new Date(dateString);
    const diffMs = now.getTime() - date.getTime();
    const diffMinutes = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMinutes / 60);
    const diffDays = Math.floor(diffHours / 24);

    if (diffMinutes < 1) return 'الآن';
    if (diffMinutes < 60) return `منذ ${diffMinutes} دقيقة`;
    if (diffHours < 24) return `منذ ${diffHours} ساعة`;
    if (diffDays === 1) return 'أمس';
    if (diffDays < 7) return `منذ ${diffDays} أيام`;
    return formatAdminDateTime(dateString);
  };

  // ---------------------------------------------------------------------------
  // Loading State
  // ---------------------------------------------------------------------------
  if (loading) {
    return (
      <div className="space-y-6 animate-pulse">
        <div className="h-10 bg-slate-200 dark:bg-slate-800 rounded-lg w-48"></div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map(i => (
            <div key={i} className="h-28 bg-white dark:bg-[#111c30] rounded-xl border border-slate-200 dark:border-slate-800 p-5"></div>
          ))}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 h-96 bg-white dark:bg-[#111c30] rounded-xl border border-slate-200 dark:border-slate-800"></div>
          <div className="h-96 bg-white dark:bg-[#111c30] rounded-xl border border-slate-200 dark:border-slate-800"></div>
        </div>
      </div>
    );
  }

  // ---------------------------------------------------------------------------
  // Error State
  // ---------------------------------------------------------------------------
  if (error) {
    return (
      <div className="rounded-xl border border-red-200 bg-red-50 dark:bg-red-950/30 p-6 text-red-700 dark:text-red-400 flex items-center justify-between">
        <div className="flex items-center gap-3 font-semibold">
          <AlertCircle className="w-5 h-5 text-red-600" />
          <span>{error}</span>
        </div>
        <button
          onClick={() => fetchDashboardData()}
          className="px-4 py-2 bg-red-600 text-white rounded-lg text-sm font-bold hover:bg-red-700 transition-colors"
        >
          إعادة المحاولة
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">

      {/* ==================================================================== */}
      {/* 1. Header Bar with Title, Subtitle, and Live Refresh Button           */}
      {/* ==================================================================== */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200/80 dark:border-slate-800">
        <div>
          <div className="text-[11px] font-semibold tracking-wide text-[#1768C2] dark:text-blue-300 mb-0.5">
            الرئيسية / المؤشرات العامة
          </div>
          <div className="flex items-center gap-2.5">
            <h1 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white tracking-tight">
              لوحة التحكم
            </h1>
            <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 dark:bg-emerald-950/70 dark:text-emerald-300 border border-emerald-300/40">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
              بيانات مباشرة
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            مؤشرات السوق والأسعار العالمية المباشرة — شبكة ليبيا للتجارة LTN
          </p>
        </div>

        {/* Live Refresh Button & Feedback */}
        <div className="flex items-center gap-3">
          {refreshSuccess && (
            <span className="hidden sm:inline-flex items-center gap-1.5 text-xs font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/50 px-3 py-1.5 rounded-lg border border-emerald-200 dark:border-emerald-800/50 animate-fade-in">
              <CheckCircle2 size={14} />
              تم التحديث بنجاح
            </span>
          )}

          {lastRefreshedTime && !refreshSuccess && (
            <span className="hidden sm:inline-block text-[11px] text-slate-400 font-mono">
              آخر فحص: {lastRefreshedTime}
            </span>
          )}

          <button
            onClick={() => fetchDashboardData(true)}
            disabled={isRefreshing}
            className="inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-[#173B81] text-white hover:bg-blue-900 active:scale-95 text-xs sm:text-sm font-bold shadow-sm shadow-blue-950/10 transition-all disabled:opacity-60 cursor-pointer"
            title="تحديث البيانات فورياً دون إعادة تحميل الصفحة"
          >
            <RefreshCw size={16} className={isRefreshing ? "animate-spin" : ""} />
            <span>{isRefreshing ? 'جاري التحديث...' : 'تحديث البيانات'}</span>
          </button>
        </div>
      </div>

      {/* ==================================================================== */}
      {/* 2. Four Main KPI Statistic Cards (Strictly 4 Cards)                   */}
      {/* ==================================================================== */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Card 1: Active Commodities */}
        <div className="gpp-data-panel relative overflow-hidden bg-white dark:bg-[#111c30] rounded-xl p-5 border border-slate-200/90 dark:border-slate-800 shadow-xs hover:border-[#173B81]/40 dark:hover:border-sky-500/30 transition-all duration-200">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400">السلع النشطة</span>
            <div className="p-2 rounded-lg bg-blue-50 dark:bg-blue-950/60 text-[#173B81] dark:text-sky-400 border border-blue-100 dark:border-blue-900/40">
              <Tag size={18} />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-slate-900 dark:text-white tabular-nums font-mono">
              {stats.activeCommoditiesCount}
            </span>
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">سلعة مفعّلة</span>
          </div>
          <div className="mt-2 text-[11px] text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            <span>متاحة في مؤشرات التداول</span>
          </div>
        </div>

        {/* Card 2: Today's Visits */}
        <div className="relative overflow-hidden bg-white dark:bg-[#111c30] rounded-xl p-5 border border-slate-200/90 dark:border-slate-800 shadow-xs hover:border-[#1e3a8a]/40 dark:hover:border-sky-500/30 transition-all duration-200">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400">زيارات اليوم</span>
            <div className="p-2 rounded-lg bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 border border-emerald-100 dark:border-emerald-900/40">
              <Eye size={18} />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-slate-900 dark:text-white tabular-nums font-mono">
              {stats.todayVisitsCount.toLocaleString('en-US')}
            </span>
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">زيارة</span>
          </div>
          <div className="mt-2 text-[11px] text-slate-500 dark:text-slate-400 font-medium">
            منذ بداية اليوم (00:00 بتوقيت ليبيا)
          </div>
        </div>

        {/* Card 3: Last Price Update */}
        <div className="relative overflow-hidden bg-white dark:bg-[#111c30] rounded-xl p-5 border border-slate-200/90 dark:border-slate-800 shadow-xs hover:border-[#1e3a8a]/40 dark:hover:border-sky-500/30 transition-all duration-200">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400">آخر تحديث للأسعار</span>
            <div className="p-2 rounded-lg bg-amber-50 dark:bg-amber-950/60 text-amber-600 dark:text-amber-400 border border-amber-100 dark:border-amber-900/40">
              <Clock size={18} />
            </div>
          </div>
          <div className="mt-3">
            <span className="text-lg font-black text-slate-900 dark:text-white truncate block">
              {formatRelativeTime(stats.lastPriceUpdate)}
            </span>
          </div>
          <div className="mt-2 text-[11px] text-slate-500 dark:text-slate-400 font-mono truncate">
            {stats.lastPriceUpdate ? formatAdminDateTime(stats.lastPriceUpdate) : 'لم يتم تسجيل تحديث'}
          </div>
        </div>

        {/* Card 4: New / Unread Messages */}
        <div className="relative overflow-hidden bg-white dark:bg-[#111c30] rounded-xl p-5 border border-slate-200/90 dark:border-slate-800 shadow-xs hover:border-[#1e3a8a]/40 dark:hover:border-sky-500/30 transition-all duration-200">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500 dark:text-slate-400">الرسائل الجديدة</span>
            <div className="p-2 rounded-lg bg-rose-50 dark:bg-rose-950/60 text-rose-600 dark:text-rose-400 border border-rose-100 dark:border-rose-900/40">
              <MessageSquare size={18} />
            </div>
          </div>
          <div className="mt-3 flex items-baseline gap-2">
            <span className="text-3xl font-black text-slate-900 dark:text-white tabular-nums font-mono">
              {stats.unreadMessagesCount}
            </span>
            <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">غير مقروءة</span>
          </div>
          <div className="mt-2 text-[11px] font-semibold">
            {stats.unreadMessagesCount > 0 ? (
              <Link to="/messages" className="text-rose-600 dark:text-rose-400 hover:underline flex items-center gap-1">
                <span>عرض الرسائل الواردة</span>
                <ArrowUpRight size={13} />
              </Link>
            ) : (
              <span className="text-slate-400 dark:text-slate-500">تم الاطلاع على جميع الرسائل</span>
            )}
          </div>
        </div>

      </div>

      {/* ==================================================================== */}
      {/* 3. Interactive Price Movement Chart with Commodity Selector           */}
      {/* ==================================================================== */}
      <div className="bg-white dark:bg-[#111c30] rounded-xl border border-slate-200/90 dark:border-slate-800 p-5 sm:p-6 shadow-xs">
        
        {/* Chart Header & Controls */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800/80">
          <div>
            <div className="flex items-center gap-2">
              <div className="p-1.5 rounded-md bg-blue-100 dark:bg-blue-900/40 text-[#1e3a8a] dark:text-sky-400">
                <BarChart3 size={18} />
              </div>
              <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
                حركة الأسعار العالمية المباشرة
              </h2>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              رسم بياني تفاعلي يعرض السلاسل الزمنية التاريخية للسلعة المختارة بناءً على البيانات المسجلة
            </p>
          </div>

          {/* Commodity Selector Chips */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
            {commodities.map(c => {
              const isSelected = (c.symbol === selectedSymbol);
              return (
                <button
                  key={c.id}
                  onClick={() => setSelectedSymbol(c.symbol)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold whitespace-nowrap transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-[#1e3a8a] text-white shadow-xs dark:bg-blue-600'
                      : 'bg-slate-100 text-slate-700 hover:bg-slate-200/80 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700'
                  }`}
                >
                  <span>{c.name_ar}</span>
                  <span className="mr-1 opacity-70 font-mono font-normal">({c.symbol})</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Commodity Highlight Strip (Bloomberg Terminal Style) */}
        {currentCommodity && (
          <div className="mt-4 p-4 rounded-lg bg-slate-50 dark:bg-slate-900/60 border border-slate-200/80 dark:border-slate-800 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div>
                <span className="text-xs font-bold text-slate-400 dark:text-slate-500 block uppercase font-mono">
                  {currentCommodity.symbol} • {currentCommodity.sector}
                </span>
                <span className="text-base font-extrabold text-slate-900 dark:text-white">
                  {currentCommodity.name_ar}
                </span>
                <span className="text-xs text-slate-500 dark:text-slate-400 mr-2" dir="ltr">
                  ({currentCommodity.name_en})
                </span>
              </div>
            </div>

            <div className="flex items-center gap-6">
              {/* Current Price */}
              <div>
                <span className="text-[11px] font-bold text-slate-400 block">السعر الحالي</span>
                <div className="text-xl font-black text-slate-900 dark:text-white font-mono tabular-nums">
                  {currentCommodity.price?.toFixed(2)}
                  <span className="text-xs font-normal text-slate-500 mr-1">{currentCommodity.unit || ''}</span>
                </div>
              </div>

              {/* Day Change */}
              <div>
                <span className="text-[11px] font-bold text-slate-400 block">التغير</span>
                <div className={`text-base font-bold font-mono tabular-nums flex items-center gap-1 ${
                  (currentCommodity.change_value ?? 0) > 0 ? 'text-emerald-600 dark:text-emerald-400' :
                  (currentCommodity.change_value ?? 0) < 0 ? 'text-red-600 dark:text-red-400' :
                  'text-slate-600 dark:text-slate-400'
                }`}>
                  {(currentCommodity.change_value ?? 0) > 0 ? <TrendingUp size={15} /> :
                   (currentCommodity.change_value ?? 0) < 0 ? <TrendingDown size={15} /> :
                   <Minus size={15} />}
                  <span>{currentCommodity.change_value ? (currentCommodity.change_value > 0 ? `+${currentCommodity.change_value}` : currentCommodity.change_value) : '0.00'}</span>
                  <span>({currentCommodity.change_percent ? (currentCommodity.change_percent > 0 ? `+${currentCommodity.change_percent}%` : `${currentCommodity.change_percent}%`) : '0%'})</span>
                </div>
              </div>

              {/* Day High / Low */}
              <div className="hidden sm:block">
                <span className="text-[11px] font-bold text-slate-400 block">أعلى / أدنى اليوم</span>
                <div className="text-xs font-mono font-semibold text-slate-700 dark:text-slate-300">
                  <span className="text-emerald-600 dark:text-emerald-400">{currentCommodity.high?.toFixed(2) || '---'}</span>
                  <span className="mx-1.5 text-slate-400">/</span>
                  <span className="text-red-600 dark:text-red-400">{currentCommodity.low?.toFixed(2) || '---'}</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Chart Canvas Area */}
        <div className="mt-5 h-72 sm:h-80 w-full">
          {chartData.length > 0 ? (
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData} margin={{ top: 10, right: 10, left: 10, bottom: 0 }}>
                <defs>
                  <linearGradient id="gppPriceGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#0284c7" stopOpacity={0.4}/>
                    <stop offset="95%" stopColor="#0284c7" stopOpacity={0.0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#cbd5e1" opacity={0.3} />
                <XAxis 
                  dataKey="date" 
                  stroke="#94a3b8" 
                  fontSize={11} 
                  tickLine={false}
                  axisLine={{ stroke: '#94a3b8', opacity: 0.3 }}
                />
                <YAxis 
                  domain={['auto', 'auto']} 
                  orientation="right" 
                  stroke="#94a3b8" 
                  fontSize={11}
                  tickLine={false}
                  axisLine={{ stroke: '#94a3b8', opacity: 0.3 }}
                  tickFormatter={(val) => Number(val).toFixed(1)}
                />
                <Tooltip
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="bg-slate-900 text-white p-3 rounded-lg shadow-xl border border-slate-700 text-xs font-mono space-y-1">
                          <div className="text-slate-400 text-[10px] pb-1 border-b border-slate-800">
                            {data.fullDate || data.date}
                          </div>
                          <div className="text-sky-300 font-bold text-sm">
                            السعر: {Number(data.price).toFixed(2)} {currentCommodity?.unit || ''}
                          </div>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Area 
                  type="monotone" 
                  dataKey="price" 
                  stroke="#0284c7" 
                  strokeWidth={2.5}
                  fillOpacity={1} 
                  fill="url(#gppPriceGradient)" 
                />
              </AreaChart>
            </ResponsiveContainer>
          ) : (
            /* Clear Empty State when no history is recorded yet for this asset */
            <div className="h-full flex flex-col items-center justify-center p-8 text-center bg-slate-50/70 dark:bg-slate-900/30 rounded-xl border border-dashed border-slate-200 dark:border-slate-800">
              <BarChart3 className="w-12 h-12 text-slate-300 dark:text-slate-600 mb-2" />
              <h3 className="text-sm font-bold text-slate-700 dark:text-slate-300">
                لا توجد بيانات تاريخية مسجلة لهذه السلعة حالياً
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 max-w-sm">
                ستظهر نقاط الحركة السعرية على الرسم البياني تلقائياً عند تسجيل تحديثات أسعار جديدة في شاشة الأسعار.
              </p>
              <Link 
                to="/prices" 
                className="mt-3 inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-50 dark:bg-blue-950/60 text-[#1e3a8a] dark:text-sky-400 text-xs font-bold hover:underline"
              >
                <span>الانتقال لإدارة الأسعار</span>
                <ArrowUpRight size={13} />
              </Link>
            </div>
          )}
        </div>
      </div>

      {/* ==================================================================== */}
      {/* 4 & 5. Lower Section: Price Ticker Table (Left) & Recent Activity (Right) */}
      {/* ==================================================================== */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

        {/* 4. Concise Price Updates Table (2/3 width on desktop) */}
        <div className="lg:col-span-2 bg-white dark:bg-[#111c30] rounded-xl border border-slate-200/90 dark:border-slate-800 p-5 sm:p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100 dark:border-slate-800/80">
              <div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Activity size={18} className="text-[#1e3a8a] dark:text-sky-400" />
                  <span>آخر تحديثات الأسعار</span>
                </h3>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  جدول ملخص للسلع النشطة وأحدث التغيرات المسجلة
                </p>
              </div>

              {/* Table search & View All link */}
              <div className="flex items-center gap-3">
                <div className="relative">
                  <Search size={14} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input
                    type="text"
                    value={tableSearch}
                    onChange={(e) => setTableSearch(e.target.value)}
                    placeholder="بحث في السلع..."
                    className="pr-8 pl-3 py-1.5 text-xs rounded-lg border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-900/60 focus:ring-1 focus:ring-[#1e3a8a] outline-none text-slate-900 dark:text-white w-36 sm:w-44 transition-all"
                  />
                </div>

                <Link
                  to="/prices"
                  className="inline-flex items-center gap-1 text-xs font-bold text-[#1e3a8a] dark:text-sky-400 hover:underline shrink-0"
                >
                  <span>عرض الكل</span>
                  <ArrowUpRight size={13} />
                </Link>
              </div>
            </div>

            {/* Table */}
            <div className="mt-4 overflow-x-auto">
              {filteredCommodities.length > 0 ? (
                <table className="w-full text-right text-xs">
                  <thead>
                    <tr className="border-b border-slate-100 dark:border-slate-800 text-slate-400 font-bold">
                      <th className="py-2.5 px-3">السلعة</th>
                      <th className="py-2.5 px-3">القطاع</th>
                      <th className="py-2.5 px-3">السعر الحالي</th>
                      <th className="py-2.5 px-3">التغير اليومي</th>
                      <th className="py-2.5 px-3 hidden sm:table-cell">أعلى / أدنى</th>
                      <th className="py-2.5 px-3 text-left">التحديث</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60 font-medium">
                    {filteredCommodities.map((c) => {
                      const isUp = (c.change_value ?? 0) > 0;
                      const isDown = (c.change_value ?? 0) < 0;

                      return (
                        <tr 
                          key={c.id} 
                          className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors"
                        >
                          {/* Symbol & Name */}
                          <td className="py-3 px-3">
                            <div className="font-extrabold text-slate-900 dark:text-white font-mono text-sm">
                              {c.symbol}
                            </div>
                            <div className="text-[11px] text-slate-500 dark:text-slate-400 truncate max-w-[140px]">
                              {c.name_ar}
                            </div>
                          </td>

                          {/* Sector */}
                          <td className="py-3 px-3 text-slate-600 dark:text-slate-400 whitespace-nowrap text-[11px]">
                            {c.sector || 'عام'}
                          </td>

                          {/* Price & Unit */}
                          <td className="py-3 px-3 font-mono font-bold text-slate-900 dark:text-white whitespace-nowrap text-sm">
                            {c.price?.toFixed(2)}
                            <span className="text-[10px] font-normal text-slate-500 mr-1">{c.unit || ''}</span>
                          </td>

                          {/* Change Value & Percent Badge */}
                          <td className="py-3 px-3 whitespace-nowrap">
                            <span className={`inline-flex items-center gap-1 font-mono font-bold text-xs px-2 py-0.5 rounded-md ${
                              isUp ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-400' :
                              isDown ? 'bg-red-50 text-red-700 dark:bg-red-950/60 dark:text-red-400' :
                              'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-400'
                            }`}>
                              {isUp ? <TrendingUp size={12} /> : isDown ? <TrendingDown size={12} /> : <Minus size={12} />}
                              <span>{c.change_percent ? (isUp ? `+${c.change_percent}%` : `${c.change_percent}%`) : '0%'}</span>
                            </span>
                          </td>

                          {/* High / Low */}
                          <td className="py-3 px-3 font-mono text-[11px] text-slate-600 dark:text-slate-400 whitespace-nowrap hidden sm:table-cell">
                            <span className="text-emerald-600 dark:text-emerald-400 font-semibold">{c.high?.toFixed(2) || '---'}</span>
                            <span className="mx-1 text-slate-400">/</span>
                            <span className="text-red-600 dark:text-red-400 font-semibold">{c.low?.toFixed(2) || '---'}</span>
                          </td>

                          {/* Last updated */}
                          <td className="py-3 px-3 text-left text-[11px] text-slate-500 dark:text-slate-400 font-mono whitespace-nowrap">
                            {formatRelativeTime(c.updated_at)}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              ) : (
                <div className="py-12 text-center text-slate-400 dark:text-slate-500 text-xs">
                  لا توجد سلع مطابقة لمعايير البحث
                </div>
              )}
            </div>
          </div>

          {/* Quick Footer inside Table */}
          <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
            <span>إجمالي السلع المعروضة: {filteredCommodities.length} من {commodities.length}</span>
            <Link to="/prices" className="font-bold text-[#1e3a8a] dark:text-sky-400 hover:underline">
              إدارة وتعديل الأسعار الكاملة ←
            </Link>
          </div>
        </div>

        {/* 5. Recent Activity Feed (1/3 width on desktop) */}
        <div className="bg-white dark:bg-[#111c30] rounded-xl border border-slate-200/90 dark:border-slate-800 p-5 sm:p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800/80">
              <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Clock size={17} className="text-amber-500" />
                <span>آخر الأنشطة والتحديثات</span>
              </h3>
              <span className="text-[10px] font-bold text-slate-400 bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded-sm">
                حيّة
              </span>
            </div>

            <div className="mt-4 space-y-4">
              {recentActivities.length > 0 ? (
                recentActivities.map((item) => (
                  <div key={item.id} className="flex items-start gap-3 text-xs group">
                    <div className="p-2 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 shrink-0 mt-0.5">
                      {item.type === 'price' && <TrendingUp size={14} className="text-blue-600 dark:text-sky-400" />}
                      {item.type === 'report' && <FileText size={14} className="text-emerald-600 dark:text-emerald-400" />}
                      {item.type === 'news' && <Newspaper size={14} className="text-amber-600 dark:text-amber-400" />}
                      {item.type === 'message' && <MessageSquare size={14} className="text-rose-600 dark:text-rose-400" />}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-bold text-slate-800 dark:text-slate-200 truncate">
                          {item.title}
                        </span>
                        {item.badge && (
                          <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded-sm border shrink-0 ${item.badgeColor || ''}`}>
                            {item.badge}
                          </span>
                        )}
                      </div>

                      {item.subtitle && (
                        <p className="text-[11px] text-slate-500 dark:text-slate-400 mt-0.5 truncate">
                          {item.subtitle}
                        </p>
                      )}

                      <div className="flex items-center justify-between mt-1 text-[10px] text-slate-400 font-mono">
                        <span>{formatRelativeTime(item.timestamp)}</span>
                        {item.link && (
                          <Link 
                            to={item.link} 
                            className="text-[#1e3a8a] dark:text-sky-400 font-bold hover:underline opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            عرض التفاصيل
                          </Link>
                        )}
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="py-12 text-center text-slate-400 text-xs">
                  لا توجد أنشطة مسجلة مؤخراً
                </div>
              )}
            </div>
          </div>

          {/* Quick Shortcuts in Activity Box */}
          <div className="mt-5 pt-3 border-t border-slate-100 dark:border-slate-800">
            <div className="grid grid-cols-2 gap-2 text-center">
              <Link 
                to="/prices" 
                className="px-2.5 py-2 rounded-lg bg-slate-50 dark:bg-slate-900 text-slate-700 dark:text-slate-300 hover:bg-slate-100 text-xs font-bold transition-colors"
              >
                تحديث الأسعار
              </Link>
              <Link 
                to="/published-reports" 
                className="px-2.5 py-2 rounded-lg bg-slate-50 dark:bg-slate-900 text-slate-700 dark:text-slate-300 hover:bg-slate-100 text-xs font-bold transition-colors"
              >
                نشر تقرير جديد
              </Link>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
}
